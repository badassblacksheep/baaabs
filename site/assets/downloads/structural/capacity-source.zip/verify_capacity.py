"""Check changed load handling and both sides of each published headcount boundary."""
import json,numpy as np
from pathlib import Path
import screen,capacity_screen
from bearing import check_bearings
from build_capacity import solve,CEILING
from build_shoring import footprint_sweep
p=Path(__file__).parent;g=json.loads((p/'geometry-38.json').read_text());d=json.loads((p/'design.json').read_text());output=[]
screen.check_element();check_bearings()
for wall in [.003175,.0047625,.00635]:
 args=dict(dancers=12,patches=footprint_sweep(12)+footprint_sweep(7.2),shore_k=5000,shore_points=d['shore_positions_m'])
 a,_=screen.analyze(g,'workshop_rear',wall,True,'touching',3,**args)
 b,_=capacity_screen.analyze(g,'workshop_rear',wall,True,'touching',3,live_multiplier=1,**args)
 for x,y in zip(a,b):
  for key in ('total_lbf','max_normal_MPa','deck_drop_in','shore_peak_lbf'):assert abs(x[key]-y[key])<1e-5
 data=json.loads((p/f'capacity-{wall*1000:g}.json').read_text())
 default=next(s for s in data if s['stiffness']==5000 and s['multiplier']==2)
 for n in [default['ceiling'],default['ceiling']+1]:
  fine=solve(wall,2,5000,n,5);coarse=default['results'][n]
  assert fine['belowCeiling']==coarse['belowCeiling']
  errors={k:abs(fine[k]-coarse[k])/max(abs(fine[k]),1e-6)for k in ['stress','drop','shore']}
  assert max(errors.values())<.01,errors
  assert abs(fine['total']- (a[0]['total_lbf']+450*n))<.001
  output.append(dict(wall_mm=wall*1000,people=n,refinement3=coarse,refinement5=fine,relative_difference=errors))
  print(wall,n,'boundary verified',errors,flush=True)
(p/'capacity-verification.json').write_text(json.dumps(dict(element_and_bearing_checks='passed',alpha_1_replay='matched iteration 02 to 1e-5 output units',live_load_total='dead load + 2 * 225 * N lbf verified',boundary_checks=output),indent=2)+'\n')
