import sys,json,time
from pathlib import Path
from build_capacity import solve
p=Path(__file__).parent;wall=float(sys.argv[1]);f=p/f'capacity-{wall*1000:g}.json'
# Independent run starts after this wall's boundary study completes.
if not f.exists():raise SystemExit('Run build_capacity first')
rows=json.loads(f.read_text());target=next(r for r in rows if r['multiplier']==2 and r['stiffness']==5000)
for n in range(len(target['results']),31):
 target['results'].append(solve(wall,2,5000,n))
 if n%5==0:print(wall,n,'done',flush=True)
f.write_text(json.dumps(rows,separators=(',',':'))+'\n')
