# Earl Thomas — iteration 03 conceptual headcount screen

2026-11-14. Same 38 × 8 ft geometry and two compression-only shores as iteration 02. Results are concept comparisons, subject to change after surveying Earl Thomas. They are not released admission limits.

## Selected basis

- 225 lbf per person; dead load D is unchanged, people load is multiplied by alpha.
- Default alpha = 2, a selected equivalent-static sensitivity. It is not a bound on rhythmic forces or resonance.
- Default effective spring stiffness = 5,000 lbf/in per complete shore/body/chassis load path. Actual strength and stiffness are unverified.
- Assumed yield = 345 MPa. Selected normal-stress ceiling = 0.60 Fy = 207 MPa.
- Criterion: every integer headcount through the reported ceiling remains at or below 207 MPa across the evaluated load family. The next integer exceeds it.

Default ceilings: 7 people for 1/8 inch, 10 for 3/16 inch, 13 for 1/4 inch. Approximate amplified-load deck drops at those ceilings: 1.133, 1.120, 1.113 in. No deflection/vibration acceptance criterion is imposed, so these are stress-screen limits only.

## Equations and algorithm

K(t)u = f_D(t) + alpha*N*225*q_p(N) + B^T*r, with forces consistently converted to SI units. q_p is the normalized gravity placement vector. Vertical displacement is positive upward. A compression-only spring supplies r_i = k_i*max(0,-u_i). Four active sets are enumerated for two bearings. Original fixed chassis seats may take tension.

For each rectangular hollow section:
A = b*h - (b-2t)*(h-2t)
I_y = [b*h^3 - (b-2t)*(h-2t)^3]/12
I_z = [h*b^3 - (h-2t)*(b-2t)^3]/12
sigma = abs(N_axial)/A + abs(M_y)*h/(2*I_y) + abs(M_z)*b/(2*I_z)

Each integer N is solved directly; footprints depend on actual N, never on alpha*N. The multiplier changes force, while the physical crowd footprint retains N people. Peak results are independent envelopes across the fixed placement cases and moving driver-side patches. Patches are 12 × 4 ft and (0.6N) × 4 ft, stepped by one foot plus exact center and aftmost positions. The first criterion exceedance ends the ceiling search (maximum search 60). The default scenario is additionally solved through 30 for the interactive target comparison. All published ceilings are bounded by a next-person exceedance.

## Reproduce

Python 3 and NumPy are required. Extract into one directory and run:

```sh
python3 build_capacity.py 0.003175
python3 extend_capacity.py 0.003175
python3 build_capacity.py 0.0047625
python3 extend_capacity.py 0.0047625
python3 build_capacity.py 0.00635
python3 extend_capacity.py 0.00635
python3 assemble_capacity.py
python3 verify_capacity.py
```

The included wall result files and `shoring-data.json` also permit `assemble_capacity.py` to reproduce `capacity-data.json` immediately. `capacity_screen.py` differs from iteration 02's `screen.py` only by multiplying people load through a separate `live_multiplier` argument. Geometry, dead load and spring formulation are unchanged.

`capacity-verification.json` contains the completed alpha=1 regression and mesh-boundary checks. The six default boundary cases (last included and next excluded count for every wall) retained their classification at refinements 3 and 5. Peak normal stress and shore force were unchanged at practical reported precision. Maximum relative displacement difference was approximately 0.129%. Every solve checks gravity totals, force/moment balance and bearing compatibility. The original axial, cantilever and bearing separation/rigid-limit tests also pass.

## Display interpretation

R = 207/sigma_max. Green: R >= 1.25; yellow: 1 <= R < 1.25; red: R < 1. The displayed yield-only factor is 345/sigma_max. It is not whole-structure safety.

Score = 100 * [w*min(R/1.25,1) + (1-w)*M_min/M_t]. Weights w = 0.70 default, 0.90 for margin preference, 0.50 for weight preference. Mass is frame plus plywood only. The highest score among options with R >= 1 is recommended for comparison. If none qualifies, the page recommends revising the design. Scores are preference rankings, not reliability probabilities or engineering release decisions.

## Conceptual shores in the model

The workshop runtime adds two orange struts at X=-0.2618115 m, Y=±1.1692 m. Top pads bear against the modeled girder undersides at Z=3.8304 m. Lower landing display elevation Z=2.787072 m comes from intersecting the existing reference roof mesh at those coordinates. It does not locate or verify a structural bow. Display struts are 70 mm square; pads are 20 mm thick, upper 180 × 160 mm, lower 600 × 180 mm. Those are illustration dimensions, not selected sections or fabrication details. Their weight and strength are unassigned. The effective spring remains the analytical representation. The original panels, portals, interior posts and deck dimensions are unchanged.

## Unresolved engineering

This is not a completed allowable-strength or code check. Combined shear/torsion, local buckling, member stability, joints, welds/bolts, chassis flexibility, shore strength, actual landing capacity, full dead load, dancing frequency/damping/acceleration, fatigue and vehicle stability remain unverified. Original rail seats can develop uplift. Deflection is reported without an acceptance threshold. The conceptual count must be revisited after survey and full structural/vehicle review.

Report: https://baaabs.org/structural/
Iteration 02: https://baaabs.org/structural/iteration-02.html
Iteration 01: https://baaabs.org/structural/baseline.html
