"""Conditional headcount screen. This does not assign an operating occupancy."""
from pathlib import Path
import json,sys
from capacity_screen import analyze,check_element
from bearing import check_bearings
from build_shoring import footprint_sweep
HERE=Path(__file__).parent
CEILING=0.6*345

def solve(wall,alpha,k,n,refinement=3):
    records=json.loads((HERE/'geometry-38.json').read_text())
    design=json.loads((HERE/'design.json').read_text())
    patches=footprint_sweep(12.) if n else []
    if n and n!=20:patches+=footprint_sweep(.6*n)
    rows,reactions=analyze(records,'workshop_rear',wall,True,'touching',refinement,dancers=n,
      patches=patches,shore_points=design['shore_positions_m'],shore_k=float('inf')if k=='rigid'else k,live_multiplier=alpha)
    stress=max(rows,key=lambda r:r['max_normal_MPa']);drop=max(rows,key=lambda r:r['deck_drop_in']);shore=max(rows,key=lambda r:r['shore_peak_lbf'])
    return dict(people=n,stress=stress['max_normal_MPa'],drop=drop['deck_drop_in'],shore=shore['shore_peak_lbf'],
      member=stress['critical_member'],stressCase=stress['case'],dropCase=drop['case'],shoreCase=shore['case'],
      compression=max(r['peak_axial_post_lbf']for r in rows),uplift=max(0,-min(r['Fz_lbf']for r in reactions)),
      total=rows[-1]['total_lbf'],shoreCompression=max(r['shore_compression_in']for r in rows),
      belowCeiling=stress['max_normal_MPa']<=CEILING)

def build(wall):
    output=[]
    # Explore force amplification and body-path stiffness separately around the trial.
    scenarios=[(a,5000)for a in [1,1.5,2,3]]+[(2,k)for k in [1000,20000,'rigid']]
    for alpha,k in scenarios:
      rows=[]
      for n in range(61):
        row=solve(wall,alpha,k,n);rows.append(row)
        if not row['belowCeiling']:break
      last=next((r['people']-1 for r in rows if not r['belowCeiling']),60)
      output.append(dict(multiplier=alpha,stiffness=k,ceiling=last,bounded=last<60,results=rows))
      print(wall,alpha,k,'ceiling',last,'next stress',rows[-1]['stress'],flush=True)
    (HERE/f'capacity-{wall*1000:g}.json').write_text(json.dumps(output,separators=(',',':'))+'\n')
if __name__=='__main__':
    check_element();check_bearings();build(float(sys.argv[1]))
