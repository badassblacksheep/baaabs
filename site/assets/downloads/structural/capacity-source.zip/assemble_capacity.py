import json
from pathlib import Path
p=Path(__file__).parent
old=json.loads((p/'shoring-data.json').read_text())
design=json.loads((p/'design.json').read_text())
walls=[dict(wallInches=t,dead=old['walls'][i]['dead'],scenarios=json.loads((p/f'capacity-{mm}.json').read_text()))for i,(t,mm)in enumerate([(.125,'3.175'),(.1875,'4.7625'),(.25,'6.35')])]
data=dict(revision='03-conceptual-headcount',date='2026-11-14',yieldMPa=345,stressCeilingMPa=207,defaultMultiplier=2,defaultStiffness=5000,defaultPriority=.7,defaultTarget=20,
 qualifier='As modeled conceptually, subject to change once we survey our specific bus, Earl Thomas.',
 interpretation='Integer ceilings of a selected normal-stress screen. Operating occupancy, deflection/vibration suitability and whole-structure safety remain unestablished.',
 criteria=dict(liveLoadMultiplier='Selected equivalent-static sensitivity; not a bound on rhythmic forces',stressCeiling='0.60 times assumed yield; simplified project screen, not code compliance',headcountSearch='Direct integer solutions, stop at first exceedance; default scenario additionally solved through 30 for comparison',score='100 * (w * min((207/stress)/1.25, 1) + (1-w) * minMass/mass)',colors=dict(green='207/stress >= 1.25',yellow='1 <= 207/stress < 1.25',red='207/stress < 1')),
 unchangedGeometry=design,modelShoring=dict(position_m=design['shore_positions_m'],landing_z_m=2.787072,visual_strut_width_m=.07,visual_pad_thickness_m=.02,visual_top_pad_dimensions_m=[.18,.16],visual_lower_pad_dimensions_m=[.60,.18],status='Display dimensions only, unverified sections and structural landing geometry',mass_included=False),walls=walls)
(p/'capacity-data.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
