import json,sys,time
from pathlib import Path
from screen04 import analyze,check_element
from bearing04 import check_bearings
from build_shoring import footprint_sweep
from design04 import *

def solve(family,pairs,wall,n,refinement=3,alpha=2,k=5000,legacy=False,cabin=4,domain='interior',panel_lbf=0., sill_wall=None,disabled_shores=()):
    r=records(family,pairs,cabin,domain)
    if sill_wall is not None:
        for m in r:
            if "Front transverse sill" in m["name"]:m["wall"]=.93*sill_wall
    if legacy:
        for m in r:m.pop('wall',None)
    patches=footprint_sweep(12.) if n else []
    if n and n!=20:patches+=footprint_sweep(min(38.,.6*n))
    rows,reactions=analyze(r,'workshop_rear',wall if legacy else .93*wall,True,'touching',refinement,dancers=n,patches=patches,
      shore_points=shores(pairs,domain),shore_k=k,live_multiplier=alpha,shore_dead_lbf=0 if legacy else shore_mass(family),panel_lbf=panel_lbf,nominal_mass=not legacy,disabled_shores=disabled_shores)
    s=max(rows,key=lambda r:r['max_normal_MPa']);d=max(rows,key=lambda r:r['deck_drop_in']);v=max(rows,key=lambda r:r['shore_peak_lbf'])
    return dict(people=n,stress=s['max_normal_MPa'],drop=d['deck_drop_in'],shore=v['shore_peak_lbf'],
      shoreReactions=v['shore_reactions_lbf'],member=s['critical_member'],criticalX=s['critical_x_m'],stressCase=s['case'],
      dropCase=d['case'],shoreCase=v['case'],compression=max(r['peak_axial_post_lbf']for r in rows),
      uplift=max(0,-min(r['Fz_lbf']for r in reactions)),total=rows[-1]['total_lbf'],dead=rows[0]['total_lbf'],
      shoreCompression=max(r['shore_compression_in']for r in rows),belowCeiling=s['max_normal_MPa']<=207)

def build(family):
    out=[]
    for pairs in [1,2,3]:
      for wall in WALLS:
        start=time.time();r=solve(family,pairs,wall,20)
        out.append(dict(id=f'{family}-{pairs}-{wall*1000:g}',family=family,pairs=pairs,wallMm=wall*1000,result=r))
        print(family,pairs,wall,r['stress'],r['drop'],r['dead'],r['member'],round(time.time()-start,2),flush=True)
        (HERE/f'explore04-{family}.json').write_text(json.dumps(out,indent=2)+'\n')
if __name__=='__main__':check_element();check_bearings();build(sys.argv[1])
