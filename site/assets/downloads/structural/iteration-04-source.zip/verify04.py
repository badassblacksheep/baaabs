from build04 import *
import numpy as np
check_element();check_bearings()
checks=[]
# Exact continuation of the archived two-shore geometry with no added mass/overrides.
old=json.loads((HERE/'capacity-data.json').read_text())
for wall in WALLS:
 r=solve('flat',1,wall,20,legacy=True)
 source=next(w for w in old['walls'] if abs(w['wallMm']-wall*1000)<1e-6) if 'wallMm' in old['walls'][0] else None
 checks.append(dict(test='legacy20',wallMm=wall*1000,result=r))
for pairs in [1,2,3]:
 for wall in WALLS:
  a=solve('grid6',pairs,wall,20,cabin=0,domain='portal',panel_lbf=2311.25,sill_wall=.00635)
  b=solve('grid6',pairs,wall,20,refinement=5,cabin=0,domain='portal',panel_lbf=2311.25,sill_wall=.00635)
  assert a['belowCeiling']==b['belowCeiling']
  assert abs(a['stress']-b['stress'])/b['stress']<.01
  checks.append(dict(test='mesh20',pairs=pairs,wallMm=wall*1000,coarse=a,fine=b))
(HERE/'verification04.json').write_text(json.dumps(checks,indent=2)+'\n')
print('element, bearings, nine refinements complete',flush=True)
sensitivity=[]
for label,kwargs in [('soft-body',dict(k=1000)),('stiff-body',dict(k=20000)),('rigid-body',dict(k=float('inf'))),('no-body-credit',dict(k=0)),('3x-people',dict(alpha=3)),('one-shore-lost',dict(disabled_shores=(2,))),('middle-pair-lost',dict(disabled_shores=(2,3)))]:
 r=solve('grid6',3,.003175,20,cabin=0,domain='portal',panel_lbf=2311.25,sill_wall=.00635,**kwargs)
 sensitivity.append(dict(label=label,result=r));print(label,r['stress'],r['drop'],flush=True)
(HERE/'sensitivity04.json').write_text(json.dumps(sensitivity,indent=2)+'\n')
