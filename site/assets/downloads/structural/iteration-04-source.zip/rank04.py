from build04 import *
def run(family):
 out=[]
 for domain in ['interior','portal']:
  for pairs in [1,2,3]:
   for wall in WALLS:
    r=solve(family,pairs,wall,20,cabin=0,domain=domain,panel_lbf=2311.25,sill_wall=.00635)
    out.append(dict(id=f'{family}-{pairs}-{wall*1000:g}-c0-{domain}',family=family,pairs=pairs,wallMm=wall*1000,cabin=0,domain=domain,panelLbf=2311.25,sillWallIn=.25,result=r))
    (HERE/f'rank04-{family}.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
    print(family,domain,pairs,wall,r['stress'],flush=True)
if __name__=='__main__':run(sys.argv[1])
