# Earl Thomas — structural iteration 04

Concept comparison only. No operating occupancy, fabrication release or verified cabin-occupant protection. 20 people is the target; eight is only the owner’s minimum threshold for considering removal of cabin uprights.

Python 3 + NumPy. Run from this directory:

```sh
python3 search04.py 0
python3 search04.py 2
python3 search04.py 4
python3 rank04.py grid4
python3 rank04.py grid6
python3 final04.py 1
python3 final04.py 2
python3 final04.py 3
python3 verify04.py
python3 verify04_boundaries.py
```

`final04-selected-p*.json` are the published interactive sweeps. `search04-c*.json` are the first eight-person cabin/layout search with common 3/16-inch portal sills. `rank04-*.json` is the final 20-person, zero-cabin-post search with 1/4-inch sills. `target20.json` preserves the nine target-20 cases before strengthening the sills. Final choice: grid6, portal spacing, three pairs, nominal 1/8-inch roof wall, 1/4-inch sills; the other existing portal tubes remain at nominal 3/16 inch.

225 lbf/person; baseline equivalent-static live multiplier 2; chosen normal-stress ceiling 207 MPa; assumed yield 345 MPa. Compression-only shores: independent 5,000 lbf/in springs. Skin mass 1,849 lb plus 25% mounts = 2,311.25 lb, applied balanced, wholly driver side and wholly passenger side. The supplied page describes the other crowd sweeps and all exclusions. None of these load patterns bounds wind, resonance, concentrated hangers or arbitrary crowd placement.

`screen04.py` uses catalog HSS stiffness and stock weights for standard roof rectangles, sharp-corner metric reference members and nominal gravity weights for the latter. `hss-properties.json` states the exact source and units. The 0.93 wall factor is applied to metric stiffness, not a second time to catalog properties. Existing model connections are idealized as rigid and coincident. Joint offsets, welds, plates, local bearing, panel span rating, unweighed reinforcement and complete equipment loads are unresolved.

The bearing solver enumerates up to 64 active sets. Its diagonal equilibration, cached inverse and residual correction are subject to force/moment and complementarity assertions in every solve. `verification04.json` includes three legacy replays and nine refined target-20 solves; `boundaries04.json` checks the selected three-pair ceilings. `sensitivity04.json` includes weak/strong/rigid/no body support, 3x live force, one lost shore and a lost pair. Weak supports and lost-shore scenarios exceed the criterion.

Exact landing coordinates are hypotheses for Earl. OEM literature documents extended bows/body mounting, not these stations or rated rooftop loads. Survey and engineer the complete load path to the chassis. Rear corner transfer through the rear drop-frame remains an explicit owner-authorized assumption. Four retained rail-seat nodes can develop uplift and moments and require verified anchors.

Models are diagrammatic beam representations. The original GLB/Blender remain extraction provenance; the site runtime removes cabin uprights, changes roof members and adds each shore-count recipe. Its solid outer faces do not specify tube wall construction or fabricate-ready intersections.
