from build04 import *
PANEL=1849*1.25

def search(cabin):
    out=[]
    for domain in ['interior','portal']:
      for family in (['grid4','grid6'] if cabin==0 else ['grid4','grid6','grid4b8','grid6b8']):
       for pairs in [1,2,3]:
        for wall in WALLS:
          row=solve(family,pairs,wall,8,cabin=cabin,domain=domain,panel_lbf=PANEL)
          out.append(dict(id=f'{family}-{pairs}-{wall*1000:g}-c{cabin}-{domain}',family=family,pairs=pairs,wallMm=wall*1000,cabin=cabin,domain=domain,panelLbf=PANEL,result=row))
          (HERE/f'search04-c{cabin}.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
          print(cabin,domain,family,pairs,wall,row['stress'],row['drop'],flush=True)
if __name__=='__main__':search(int(sys.argv[1]))
