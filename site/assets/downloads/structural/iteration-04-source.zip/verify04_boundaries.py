from build04 import *
legacy=json.loads((HERE/'verification04.json').read_text())
old=json.loads((HERE/'capacity-data.json').read_text())
for v in [v for v in legacy if v['test']=='legacy20']:
 w=min(old['walls'],key=lambda w:abs(w['wallInches']*25.4-v['wallMm']))
 r=next(s for s in w['scenarios']if s['multiplier']==2 and s['stiffness']==5000)['results'][20]
 for key in ['stress','drop','shore']:assert abs(r[key]-v['result'][key])<1e-4
out=[]
for s in json.loads((HERE/'final04-selected-p3.json').read_text()):
 if s['share']!=1:continue
 for n in [s['ceiling'],s['ceiling']+1]:
  fine=solve('grid6',3,s['wallMm']/1000,n,refinement=5,cabin=0,domain='portal',panel_lbf=2311.25,sill_wall=.00635)
  assert fine['belowCeiling']==s['results'][n]['belowCeiling']
  out.append(dict(wallMm=s['wallMm'],people=n,coarse=s['results'][n],fine=fine))
(HERE/'boundaries04.json').write_text(json.dumps(out,indent=2)+'\n')
print('Legacy replay and six selected boundary classifications passed')
