from build04 import *
PANEL=1849*1.25

def build(pairs):
    out=[]
    for wall in WALLS:
      for share in [0,.5,1]:
        rows=[];ceiling=None
        for n in range(61):
          r=solve('grid6',pairs,wall,n,cabin=0,domain='portal',panel_lbf=share*PANEL,sill_wall=.00635);rows.append(r)
          if ceiling is None and not r['belowCeiling']:ceiling=n-1
          if n>=30 and ceiling is not None:break
        out.append(dict(id=f'grid6-{pairs}-{wall*1000:g}-c0-portal',family='grid6',pairs=pairs,wallMm=wall*1000,cabin=0,domain='portal',share=share,
          panelLbf=share*PANEL,ceiling=ceiling if ceiling is not None else 60,bounded=ceiling is not None,frameWeight=rows[0]['total']-share*PANEL,results=rows))
        (HERE/f'final04-selected-p{pairs}.json').write_text(json.dumps(out,separators=(',',':'))+'\n')
        print('pairs',pairs,'wall',wall,'panel share',share,'ceiling',ceiling,flush=True)
if __name__=='__main__':build(int(sys.argv[1]))
