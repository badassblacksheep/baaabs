"""Reproduce published cases with Python 3 and NumPy; --all repeats the search."""
import argparse,json
from pathlib import Path
from study05 import solve, geometry
from screen04 import check_element
from bearing04 import check_bearings
HERE=Path(__file__).parent
ap=argparse.ArgumentParser();ap.add_argument('--all',action='store_true');args=ap.parse_args()
check_element();check_bearings()
files=['equipment05.json','equipment-sensitivity05.json']
if args.all:files+=['explore05.json','light05.json','sparse05.json','robust05.json','end-only05.json','interactive05.json','light-sensitivity05.json','access05.json','accessible-final05.json']
keys=['depth','pairs','share','people','k','alpha','disabled','family','portal','truss','use_shores','fixed','access']
count=0
for filename in files:
 for expected in json.loads((HERE/filename).read_text()):
  if not args.all and not (expected.get('extraLbf')==250 and expected['people']==20):continue
  params={k:expected[k] for k in keys if k in expected}
  params['extra_lbf']=expected.get('extraLbf',0.)
  params['refinement']=5 if 'fine' in expected.get('label','') else 3
  actual=solve(**params)
  for key in ['stress','drop','frameWeight','portalReaction']:
   assert abs(actual[key]-expected[key])<.001,(filename,params,key,actual[key],expected[key])
  assert actual['belowCeiling']==expected['belowCeiling']
  assert abs(actual['total']-actual['dead']-actual['alpha']*actual['people']*225)<.02
  if not actual['use_shores']:assert actual['shore']==0 and actual['shoreReactions']==[]
  count+=1
members=geometry(.8,3,'grid6','larger','robust','reinforced')
assert not any(m['name'].startswith('Truss web') and m['name'].endswith(' 4') for m in members)
assert len([m for m in members if m['name'].startswith('Truss vertical') and m['name'].endswith((' 4',' 5')) and abs(m['depth']-.1016)<1e-9])==4
assert min(m['a'][2]-.0254 for m in members if m['name'].startswith('Lower transverse tie'))>3.133724928
print(f'{count} replayed cases, load accounting, zero body reactions, permanent access and nominal roof clearance passed.')
