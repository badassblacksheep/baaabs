"""Linear elastic frame screening. Run with Python 3 and NumPy in this directory."""
import csv
import json
import math
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
GRAVITY = 9.80665
LBF = 4.4482216152605
E = 200e9
G = E / (2 * (1 + 0.30))
RHO = 7850
PLY_PRESSURE = 0.01905 * 600 * GRAVITY
DECK_LENGTH = 10.9728
DECK_WIDTH = 2.4384
TEST_YIELD = 345e6
CASES = ('dead', 'uniform', 'party_half', 'party_midspan', 'passenger_half', 'party_rear')


CATALOG=json.loads((HERE/"hss-properties.json").read_text())["rows"]

def catalog(width,depth,wall):
    return next((r for r in CATALOG if abs(r[0]*.0254-depth)<1e-7 and abs(r[1]*.0254-width)<1e-7 and abs(.93*r[2]*.0254-wall)<1e-7),None)

def section(width, depth, wall):
    row=catalog(width,depth,wall)
    if row:return row[3]*.0254**2,row[4]*.0254**4,row[5]*.0254**4,row[6]*.0254**4
    wi, di = width - 2*wall, depth - 2*wall
    area = width * depth - wi * di
    iy = (width * depth**3 - wi * di**3) / 12
    iz = (depth * width**3 - di * wi**3) / 12
    j = 2 * wall * ((width-wall)*(depth-wall))**2 / (width+depth-2*wall)
    return area, iy, iz, j


def beam(p, q, face_axis, sec):
    axis = (q-p) / np.linalg.norm(q-p)
    ey = face_axis - axis * (axis @ face_axis)
    ey /= np.linalg.norm(ey)
    r = np.array([axis, ey, np.cross(axis,ey)])
    trans = np.kron(np.eye(4),r)
    L = np.linalg.norm(q-p)
    area, iy, iz, j = sec
    k = np.zeros((12,12))
    def block(dofs, data):
        k[np.ix_(dofs,dofs)] += data
    pair=np.array([[1,-1],[-1,1]])
    block([0,6], E*area/L * pair)
    block([3,9], G*j/L * pair)
    bend = np.array([[12,6*L,-12,6*L],[6*L,4*L**2,-6*L,2*L**2],
                     [-12,-6*L,12,-6*L],[6*L,2*L**2,-6*L,4*L**2]])
    block([1,5,7,11], E*iz/L**3 * bend)
    flip=np.array([1,-1,1,-1])
    block([2,4,8,10], E*iy/L**3 * bend * np.outer(flip,flip))
    return L,r,trans,k


def distributed(q, L):
    """Consistent nodal load in beam coordinates for constant force per unit length."""
    f=np.zeros(12)
    f[:3]=f[6:9]=q*L/2
    f[4:6]=[-q[2]*L**2/12, q[1]*L**2/12]
    f[10:12]=-f[4:6]
    return f


def check_element():
    span, force, wall = 2.1, 1120., .003175
    sec=section(.06,.10,wall)
    L,r,T,k=beam(np.zeros(3),np.array([span,0.,0.]),np.array([0.,1,0]),sec)
    for axis,expected in [(0,force*L/(E*sec[0])), (1,force*L**3/(3*E*sec[2])),
                          (2,force*L**3/(3*E*sec[1]))]:
        f=np.zeros(6); f[axis]=force
        assert np.isclose(np.linalg.solve(k[6:,6:],f)[axis],expected,rtol=1e-10)
    f=distributed(np.array([0,0,-force]),L)
    tip=np.linalg.solve(k[6:,6:],f[6:])[2]
    assert np.isclose(tip,-force*L**4/(8*E*sec[1]),rtol=1e-10)
    reactions=k@np.r_[np.zeros(6),np.linalg.solve(k[6:,6:],f[6:])] - f
    assert np.isclose(abs(reactions[4]),force*L**2/2)


def idealize(records, rear, welded, refinement, shore_points=()):
    members=[]
    joists=sorted([m for m in records if m.get('deck_joist',m['name'].startswith('Floor joist'))],key=lambda m:m['a'][0])
    girders=[m for m in records if m['name'].startswith('Deck edge')]
    y_edge=abs(girders[0]['a'][1]); top=girders[0]['a'][2]
    xfirst=joists[0]['a'][0]; has_return=any('Nose return' in m['name'] for m in records)
    bases=[]
    portal_xs=[m['a'][0] for m in records if m['name'].endswith('Front corner post') and (rear or not m['rear'])]
    sills={m['rear']:m['a'][2] for m in records if m['name'].endswith('Front transverse sill')}
    for src in records:
        if src['rear'] and not rear:continue
        m=dict(src)
        n=m['name'].split('mirror of ')[-1]
        a,b=np.array(m['a']),np.array(m['b'])
        if src.get('deck_joist',n.startswith('Floor joist')):a[1],b[1]=-y_edge,y_edge
        if n.startswith('Transverse deck bearer'): a[2]=b[2]=top
        if 'upright' in n:
            b[2]=top
            bases.append((a.copy(),n))
        if n.startswith('Front corner post'):a[2]=sills[m['rear']]
        if n.startswith('Front portal X'):a[0]=b[0]=min(portal_xs,key=lambda x:abs(x-a[0]))
        if has_return and n.startswith('Deck edge'):a[0]=xfirst
        if n.startswith('Nose return'):b[0]=xfirst
        if n=='Front transverse sill':
            for sign in [-1,1]:
                label=('Rear' if m['rear'] else 'Front')+(' driver sill seat' if sign<0 else ' passenger sill seat')
                bases.append((np.array([a[0],sign*.43,a[2]]),label))
        m.update(a=a,b=b,cuts=[0.,1.],short=n)
        members.append(m)
    def cut(m,t):
        if -1e-5<t<1+1e-5:m['cuts'].append(float(np.clip(t,0,1)))
    for i,m in enumerate(members):
        p=m['a']; d=m['b']-p
        if m.get('deck_joist',m['short'].startswith('Floor joist')):cut(m,.5)
        for base,_ in bases + [(np.array(p), "shore") for p in shore_points]:
            t=(base-p)@d/(d@d)
            if np.linalg.norm(p+t*d-base)<1e-5:cut(m,t)
        for n in members[:i]:
            a=n['a']; v=n['b']-a
            mat=np.column_stack([d,-v])
            if np.linalg.matrix_rank(mat,tol=1e-7)<2:
                # Touching endpoints of adjacent collinear members already share a node.
                continue
            t,u=np.linalg.lstsq(mat,a-p,rcond=None)[0]
            if min(t,u)<-1e-5 or max(t,u)>1.00001 or np.linalg.norm(p+t*d-a-u*v)>1e-5:continue
            both_interior=min(t,1-t,u,1-u)>1e-5
            brace_to_bearer=(('Roof bay' in n['short'] and 'Transverse deck bearer' in m['short'])
                             or ('Roof bay' in m['short'] and 'Transverse deck bearer' in n['short']))
            if welded=='touching' and brace_to_bearer:continue
            if both_interior and (('portal X' in n['short'] and 'portal X' in m['short']) or
                    (welded=='ends_only' and ('Roof bay' in n['short'] or 'Roof bay' in m['short']))):continue
            cut(m,t);cut(n,u)
    nodes=[];els=[]; lookup={}
    def index(pt):
        key=tuple(pt)
        if key in lookup:return lookup[key]
        for coords, idx in lookup.items():
            if max(abs(v-u) for v,u in zip(coords,key)) < 4e-6:return idx
        lookup[key]=len(nodes);nodes.append(pt)
        return lookup[key]
    for m in members:
        cuts=sorted(set(round(t,7) for t in m['cuts']))
        intervals=[(i,j) for i,j in zip(cuts,cuts[1:]) if (j-i)*np.linalg.norm(m['b']-m['a'])>1e-5]
        for i,j in intervals:
            ts=np.linspace(i,j,max(1,min(refinement,int((j-i)*np.linalg.norm(m["b"]-m["a"])/.05)))+1)
            for s,t in zip(ts,ts[1:]):
                p=m['a'] + s*(m['b']-m['a']);q=m['a'] + t*(m['b']-m['a'])
                # No connection at nonwelded crossings created accidentally by subdivisions.
                def endpoint(v,x):
                    if x not in (i,j) and ('Roof bay' in m['short'] or 'portal X' in m['short']):
                        nodes.append(v);return len(nodes)-1
                    return index(v)
                # Internal nodes of the same subdivision must share their DOFs.
                if s==i: prev=endpoint(p,s)
                nxt=endpoint(q,t);els.append((prev,nxt,m));prev=nxt
    support=[(index(p),n) for p,n in bases]
    return np.array(nodes),els,support,joists,girders


def analyze(records, layout, wall, fixed, welded, refinement, stability=False, dancers=20, patches=(), shore_k=0, shore_points=(), live_multiplier=1., shore_dead_lbf=0., panel_lbf=0., nominal_mass=True, disabled_shores=()):
    crowd_lbf = 225.0 * dancers * live_multiplier
    assert live_multiplier >= 1.0
    cases = CASES + tuple(label for label, _, _ in patches)
    nodes,els,support,joists,girders=idealize(records,layout=='workshop_rear',welded,refinement,shore_points)
    xmin,xmax=girders[0]['a'][0],girders[0]['b'][0]; yc=abs(girders[0]['a'][1])
    jx=np.array([j['a'][0] for j in joists]); bounds=np.r_[xmin,(jx[1:]+jx[:-1])/2,xmax]
    xmid=(xmin+xmax)/2; half_patch=1.8288
    n=len(nodes)*6; K=np.zeros((n,n)); F=np.zeros((n,len(cases))); elements=[]
    for ni,nj,m in els:
        p,q=nodes[ni],nodes[nj];w=m['width'];h=m['depth'];sec=section(w,h,m.get("wall",wall))
        L,r,T,k=beam(p,q,np.array(m['axis_y']),sec)
        ids=np.r_[np.arange(ni*6,ni*6+6),np.arange(nj*6,nj*6+6)]
        K[np.ix_(ids,ids)]+=T.T@k@T
        # Positive weights downward. Distribute deck pressure to joists by tributary length.
        stock=catalog(w,h,m.get("wall",wall))
        mass_area=section(w,h,m.get("wall",wall)/.93)[0] if nominal_mass else sec[0]
        line_weight=stock[7]*LBF/.3048 if stock else mass_area*RHO*GRAVITY
        weight=np.full(len(cases),line_weight)
        if m.get('deck_joist',m['short'].startswith('Floor joist')):
            j=int(np.argmin(abs(jx-m['a'][0])));lo,hi=bounds[j:j+2];dx=hi-lo
            y=(p[1]+q[1])/2; live=crowd_lbf*LBF*dx/((xmax-xmin)*2*yc)
            weight+=PLY_PRESSURE*DECK_WIDTH*dx/(2*yc)
            weight[1]+=live
            weight[2]+=live*2 if y<0 else 0.
            overlap=max(0,min(hi,xmid+half_patch)-max(lo,xmid-half_patch))
            weight[3]+=crowd_lbf*LBF*overlap/(2*half_patch*yc) if y<0 else 0.
            weight[4]+=live*2 if y>0 else 0.
            rear_overlap=max(0,min(hi,xmax)-max(lo,xmax-2*half_patch))
            weight[5]+=crowd_lbf*LBF*rear_overlap/(2*half_patch*yc) if y<0 else 0.
            for i, (_, start_ft, length_ft) in enumerate(patches, start=len(CASES)):
                x0=xmin+start_ft*.3048; patch_length=length_ft*.3048
                loaded=max(0.,min(hi,x0+patch_length)-max(lo,x0))
                if y<0:weight[i]+=crowd_lbf*LBF*loaded/(patch_length*yc)
        local_dens=np.outer(r@np.array([0,0,-1.]),weight)
        equiv=np.zeros((12,len(cases)))
        equiv[:3]=equiv[6:9]=local_dens*L/2
        equiv[4]=-local_dens[2]*L**2/12;equiv[5]=local_dens[1]*L**2/12
        equiv[10:12]=-equiv[4:6]
        F[ids]+=T.T@equiv
        elements.append((ids,m,L,r,T,k,local_dens,equiv,sec,ni,nj))
    if panel_lbf:
        # Evaluate balanced, all driver-side, and all passenger-side hanging skins.
        original_cases=cases
        cases=tuple(case+'|panels_'+label for label in ('balanced','driver','passenger') for case in original_cases)
        F=np.tile(F,(1,3));updated=[]
        for ids,m,L,r,T,k,dens,equiv,sec,ni,nj in elements:
            dens=np.tile(dens,(1,3));equiv=np.tile(equiv,(1,3))
            if m['short'].startswith('Deck edge'):
                side=nodes[ni,1]<0
                weights=np.repeat([.5,1. if side else 0.,0. if side else 1.],len(original_cases))*panel_lbf*LBF/(xmax-xmin)
                added=np.outer(r@np.array([0,0,-1.]),weights)
                ef=np.zeros_like(equiv);ef[:3]=ef[6:9]=added*L/2
                ef[4]=-added[2]*L**2/12;ef[5]=added[1]*L**2/12;ef[10:12]=-ef[4:6]
                dens+=added;equiv+=ef;F[ids]+=T.T@ef
            updated.append((ids,m,L,r,T,k,dens,equiv,sec,ni,nj))
        elements=updated
    constrained=np.array(sorted(ind for node,label in support for ind in range(node*6,node*6+(6 if fixed else 3))))
    free=np.setdiff1d(np.arange(n),constrained)
    U=np.zeros_like(F); Kfree=K[np.ix_(free,free)]
    shore_nodes=[]
    for pt in shore_points:
        distances=np.linalg.norm(nodes-np.array(pt),axis=1)
        idx=int(np.argmin(distances))
        assert distances[idx]<1e-5
        shore_nodes.append(idx)
    shore_dofs=np.array([6*idx+2 for idx in shore_nodes],dtype=int)
    F[shore_dofs] -= shore_dead_lbf*LBF
    active_shore_dofs=np.array([v for j,v in enumerate(shore_dofs) if j not in disabled_shores],dtype=int)
    if len(active_shore_dofs) and shore_k:
        from bearing04 import compression_bearings
        relative=np.array([int(np.where(free==idx)[0][0]) for idx in active_shore_dofs])
        U[free]=compression_bearings(Kfree,F[free],relative,shore_k*LBF/.0254)
    else:
        U[free]=np.linalg.solve(Kfree,F[free])
    R=K@U-F
    clear_free=np.setdiff1d(free,active_shore_dofs if shore_k else [])
    assert np.max(abs(R[clear_free])) < 1e-5*max(abs(F).max(),1.)
    shore_force=R[shore_dofs] if len(shore_nodes) else np.zeros((0,len(cases)))
    if shore_k:
        assert shore_force.min()>-.01
        if np.isfinite(shore_k):
            assert np.allclose(shore_force,np.maximum(0,-U[shore_dofs])*np.array([0 if j in disabled_shores else shore_k for j in range(len(shore_dofs))])[:,None]*LBF/.0254,atol=.02)
        else:
            assert U[active_shore_dofs].min()>-1e-7
    RR=R.reshape(-1,6,len(cases)); FF=F.reshape(-1,6,len(cases))
    total=-FF[:,2,:].sum(0)/LBF
    for group in total.reshape(3 if panel_lbf else 1,-1):
        assert np.allclose(group[1:]-group[0],crowd_lbf,atol=1e-3)
    forces=RR[:,:3]+FF[:,:3]
    moments=RR[:,3:]+FF[:,3:]+np.cross(nodes[:,:,None],forces,axisa=1,axisb=1,axisc=1)
    assert np.max(abs(forces.sum(0)))<.02 and np.max(abs(moments.sum(0)))<.03
    results=[];reactions=[]
    roofz=girders[0]['a'][2]
    deck_ids=np.where((abs(nodes[:,2]-roofz)<1e-4) & (nodes[:,0]>=xmin-1e-5) & (nodes[:,0]<=xmax+1e-5))[0]
    nc=len(cases)
    peak_s=np.zeros(nc); critical=np.full(nc,'',dtype=object); critical_x=np.zeros(nc)
    peak_post=np.zeros(nc); post_name=np.full(nc,'',dtype=object);post_stress=np.zeros(nc)
    upright=np.zeros(nc); upright_name=np.full(nc,'',dtype=object);euler=np.zeros(nc)
    for ids,m,L,r,T,k,dens,equiv,sec,ni,nj in elements:
        f=k@(T@U[ids])-equiv;area,iy,iz,j=sec
        for x in (0,L/2,L):
            axial=-(f[0]+dens[0]*x)
            my=f[4]+f[2]*x+dens[2]*x*x/2
            mz=f[5]-f[1]*x-dens[1]*x*x/2
            stress=abs(axial)/area+abs(my)*m['depth']/(2*iy)+abs(mz)*m['width']/(2*iz)
            mask=stress>peak_s;peak_s[mask]=stress[mask];critical[mask]=m['name']
            critical_x[mask]=nodes[ni,0]+(nodes[nj,0]-nodes[ni,0])*x/L
            if 'upright' in m['short'] or 'corner post' in m['short']:
                compression=np.maximum(0,-axial)
                mask=compression>peak_post;peak_post[mask]=compression[mask];post_name[mask]=m['name']
                post_stress=np.maximum(post_stress,stress)
                if 'upright' in m['short']:
                    mask=compression>upright;upright[mask]=compression[mask];upright_name[mask]=m['name']
                pl=np.linalg.norm(m['b']-m['a']);pe=np.pi**2*E*min(iy,iz)/pl**2
                euler=np.maximum(euler,compression/pe)
            if x==L:
                assert np.max(abs(my+f[10]))<1e-4 and np.max(abs(mz+f[11]))<1e-4
    name=lambda value:round(float(value),5)
    for c,case in enumerate(cases):
        uz=U[2::6,c];worst=deck_ids[np.argmin(uz[deck_ids])]
        results.append(dict(layout=layout,wall_mm=wall*1000,base='fixed' if fixed else 'pinned',roof_crossings=welded,case=case,
          total_lbf=name(total[c]),deck_drop_in=name(-uz[worst]/.0254),drop_x_m=name(nodes[worst,0]),drop_y_m=name(nodes[worst,1]),
          peak_axial_post_lbf=name(peak_post[c]/LBF),peak_axial_post=post_name[c],max_upright_lbf=name(upright[c]/LBF),upright=upright_name[c],
          max_post_normal_MPa=name(post_stress[c]/1e6),max_post_P_over_Euler_K1=name(euler[c]),
          max_normal_MPa=name(peak_s[c]/1e6),critical_member=critical[c],critical_x_m=name(critical_x[c]),normal_over_assumed_Fy=name(peak_s[c]/TEST_YIELD),
          shore_reactions_lbf=[name(v/LBF) for v in shore_force[:,c]],shore_peak_lbf=name(max(shore_force[:,c],default=0)/LBF),
          shore_total_lbf=name(sum(shore_force[:,c])/LBF),driver_shore_lbf=name(sum(shore_force[::2,c])/LBF),passenger_shore_lbf=name(sum(shore_force[1::2,c])/LBF),
          shore_compression_in=name(max(0,-min(U[shore_dofs,c],default=0))/.0254) if shore_k else 0.))
        for idx,label in support:
            fx,fy,fz,mx,my,mz=RR[idx,:,c]
            reactions.append(dict(case=case,support=label,Fx_lbf=name(fx/LBF),Fy_lbf=name(fy/LBF),Fz_lbf=name(fz/LBF),
              Mx_ftlb=name(mx/(LBF*.3048)),My_ftlb=name(my/(LBF*.3048)),Mz_ftlb=name(mz/(LBF*.3048))))
    if stability:
        from stability import check_frame_stability
        return check_frame_stability(Kfree, free, elements, U, F, R, support, nodes, deck_ids, layout)
    return results,reactions


def save(name,rows):
    with (HERE/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)


if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--refinement',type=int,default=3)
    args=ap.parse_args();check_element()
    models=json.loads((HERE/'geometry.json').read_text())
    archived=json.loads((HERE/'single.json').read_text())
    results=[];reactions=[]
    for layout in ('base_glb','workshop_rear','archived_single'):
        for wall,fixed,welded in [(.003175,True,'touching'),(.0047625,True,'touching'),(.003175,False,'touching'),(.003175,True,'ends_only'),(.003175,True,'bridged_gap')]:
            if layout=='archived_single' and (not fixed or welded!='touching'):continue
            a,b=analyze(archived if layout=='archived_single' else models,layout,wall,fixed,welded,args.refinement)
            results.extend(a);reactions.extend(b)
    save('cases.csv',results);save('reactions.csv',reactions)
    print('Completed',len(results),'cases;',len(reactions),'support records.')
