"""Iteration 05: bounded architecture study, NOT a structural design release.

Reuse the frozen iteration-04 frame formulation. All added members and gravity
are explicit; skin gravity may move off the deck, never disappear from the bus.
"""
import json
import math
from pathlib import Path
from design04 import records, shores, positions, shore_mass, Y, Z
from screen04 import analyze
from build_shoring import footprint_sweep

HERE = Path(__file__).parent

def geometry(depth=0., pairs=3, family='grid6', portal='original', truss='dense', access=False):
    members = records(family, pairs, cabin=0, domain='portal')
    for m in members:
        if 'Front transverse sill' in m['name']:
            m['wall'] = .93*.00635
    if depth:
        # Chords and webs occupy the existing raised-deck zone; use real
        # cross-bracing and no stiffness contribution from decorative panels.
        stations = sorted(set([-6.27, 4.81355] + [m['a'][0] for m in members
            if m['name'].startswith('Floor joist') and -6.27 < m['a'][0] < 4.81355]))
        if truss in ('light','sparse','robust'):
            main=[-6.27,*positions(pairs,'portal'),4.81355]
            stations=sorted(main+[(a+b)/2 for a,b in zip(main,main[1:])])
        def add(name, a, b, width=.0508, height=.0508, wall=.003175):
            members.append(dict(name=name, a=a, b=b, axis_y=[0,1,0] if a[1]==b[1] else [1,0,0],
                width=width, depth=height, wall=.93*wall, rear=False))
        for side,y in [('driver',-Y),('passenger',Y)]:
            add(f'Truss lower chord {side}',[-6.27,y,Z-depth],[4.81355,y,Z-depth],height=.0508 if truss=='light' else .1524 if truss=='robust' else .1016,
                wall=.0047625 if access=='reinforced' else .003175)
            for i,x in enumerate(stations):
                if i not in (0,len(stations)-1):
                    add(f'Truss vertical {side} {i}',[x,y,Z],[x,y,Z-depth],width=.0381 if truss=='light' else .0508,
                        height=.1016 if access=='reinforced' and i in (4,5) else .0381 if truss=='light' else .0508)
            for i,(a,b) in enumerate(zip(stations,stations[1:])):
                if access and i==4:
                    continue  # Permanent clear bay on both sides; never remove a loaded brace.
                za,zb=(Z,Z-depth) if i%2==0 else (Z-depth,Z)
                add(f'Truss web {side} {i}',[a,y,za],[b,y,zb],width=.0381 if truss=='light' else .0508,height=.0381 if truss=='light' else .0508)
        for i,x in enumerate(positions(pairs,'portal')):
            tie_z=max(3.21,Z-depth) if access else Z-depth
            add(f'Lower transverse tie {i}',[x,-Y,tie_z],[x,Y,tie_z])
        # Changing portal sections is separate from changing roof topology.
    if portal == 'larger':
        for m in members:
            if 'Front transverse sill' in m['name']:
                m.update(width=.0762, depth=.2032, axis_y=[1,0,0],wall=.93*.00635)
            elif 'corner post' in m['name']:
                m.update(width=.1016,depth=.1016,wall=.93*.00635)
    return members

def solve(depth=0., pairs=3, share=1., people=20, k=5000., alpha=2., disabled=(),
          refinement=3, family='grid6', portal='original', truss='dense', use_shores=True, fixed=True, access=False, extra_lbf=0.):
    r=geometry(depth,pairs,family,portal,truss,access)
    patches=footprint_sweep(12.) if people else []
    if people and people!=20: patches+=footprint_sweep(min(38.,.6*people))
    rows,reactions=analyze(r,'workshop_rear',.93*.003175,fixed,'touching',refinement,
        dancers=people,patches=patches,shore_points=shores(pairs,'portal') if use_shores else [],shore_k=k if use_shores else 0.,
        live_multiplier=alpha,shore_dead_lbf=shore_mass(family) if use_shores else 0.,panel_lbf=2311.25*share+extra_lbf,
        nominal_mass=True,disabled_shores=disabled)
    s=max(rows,key=lambda r:r['max_normal_MPa'])
    d=max(rows,key=lambda r:r['deck_drop_in'])
    v=max(rows,key=lambda r:r['shore_peak_lbf'])
    return dict(depth=depth,pairs=pairs,share=share,people=people,k=k,alpha=alpha,
        disabled=list(disabled),family=family,portal=portal,truss=truss,use_shores=use_shores,fixed=fixed,access=access,extraLbf=extra_lbf,
        stress=s['max_normal_MPa'],stressCase=s['case'],member=s['critical_member'],
        drop=d['deck_drop_in'],dropCase=d['case'],shore=v['shore_peak_lbf'],
        shoreCase=v['case'],shoreReactions=v['shore_reactions_lbf'],
        frameWeight=rows[0]['total_lbf']-2311.25*share-extra_lbf,
        dead=rows[0]['total_lbf'],total=rows[-1]['total_lbf'],
        uplift=max(0,-min(x['Fz_lbf'] for x in reactions)),
        portalReaction=max(abs(x['Fz_lbf']) for x in reactions),
        maxPortalMoment=max(abs(x[a]) for x in reactions for a in ['Mx_ftlb','My_ftlb','Mz_ftlb']),
        belowCeiling=s['max_normal_MPa']<=207.)

if __name__=='__main__':
    import sys,time
    out=[]
    jobs=[dict(depth=d,share=s) for d in [0,.3,.6004,.9] for s in [0,.5,1]]
    for kw in jobs:
        start=time.time(); result=solve(**kw);out.append(result)
        print(kw,'MPa',result['stress'],'in',result['drop'],'lb',result['frameWeight'],
              result['member'],round(time.time()-start,1),flush=True)
        (HERE/'explore05.json').write_text(json.dumps(out,indent=2)+'\n')
