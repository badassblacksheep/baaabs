"""Finite conceptual search, not a structural design release. Units: m, N, Pa."""
import json, math, copy
from pathlib import Path
from screen04 import section,RHO,GRAVITY,LBF
HERE=Path(__file__).parent
BASE=json.loads((HERE/'geometry-38.json').read_text())
X0,X1=-6.357811,5.224589
A,B=-3.475670,2.952047
Y,Z=1.1692,3.8604
FAMILIES={'flat':'Current flat grid','edge':'Same tubes on edge','grid4':'Aligned 4-inch grid','grid6':'Aligned 6-inch girders','grid4b8':'4-inch girders / 8-inch bearers','grid6b8':'6-inch girders / 8-inch bearers'}
WALLS=[.003175,.0047625,.00635]
def roof(m):return m['name'].startswith(('Deck edge','Floor joist','Roof bay','Transverse deck bearer'))
def positions(pairs,domain='interior'):
    a,b=(A,B) if domain=='interior' else (-6.27,4.81355)
    return [a+j*(b-a)/(pairs+1) for j in range(1,pairs+1)]
def shores(pairs,domain='interior'):return [[x,y,Z] for x in positions(pairs,domain) for y in [-Y,Y]]
def records(family,pairs,cabin=4,domain='interior'):
    r=copy.deepcopy(BASE)
    # Cabin=2 retains the forward transverse pair; cabin=0 removes all four.
    r=[m for m in r if not (('upright' in m['name'] or m['name'].startswith('Transverse deck bearer')) and (cabin==0 or (cabin==2 and m['name'].endswith('2'))))]
    support_xs=([A] if cabin==2 else [A,B] if cabin==4 else [])
    # Keep the chassis posts/portals at one common provisional effective wall.
    for m in r:
        if not roof(m):m['wall']=.93*.0047625
        if family!='flat':
            if m['name'].startswith('Deck edge'):m['axis_y']=[0,1,0]
            if m['name'].startswith(('Floor joist','Transverse deck bearer')):m['axis_y']=[1,0,0]
    if family.startswith('grid'):
        r=[m for m in r if not m['name'].startswith(('Floor joist','Roof bay'))]
        for m in r:
            if m['name'].startswith('Deck edge'):m.update(width=.0508,depth=.1524 if family.startswith('grid6') else .1016)
            if m['name'].startswith('Transverse deck bearer'):m.update(width=.0762 if family.endswith('b8') else .0508,depth=.2032 if family.endswith('b8') else .1524)
        # Nodes aligned to shore stations and existing support lines. Subdivide to <=24 in.
        stations=sorted(set([X0,-6.27,*support_xs,*positions(pairs,domain),4.81355,X1]))
        xs=[]
        for a,b in zip(stations,stations[1:]):
            for j in range(math.ceil((b-a)/.6096)):xs.append(a+j*(b-a)/math.ceil((b-a)/.6096))
        xs.append(X1)
        for j,x in enumerate(xs):
            existing=next((m for m in r if (m['name'].startswith('Transverse deck bearer') or 'portal crossmember.001' in m['name']) and abs(m['a'][0]-x)<1e-5),None)
            if existing:
                existing['deck_joist']=True
                continue
            r.append(dict(name=f'Floor joist {j:02d}',rear=False,a=[x,-Y,Z],b=[x,Y,Z],axis_y=[1,0,0],width=.0508,depth=.1016))
        # Retain triangulation in plan; no plywood diaphragm credited.
        bays=sorted(set([-6.27,*support_xs,*positions(pairs,domain),4.81355]))
        for j,(a,b) in enumerate(zip(bays,bays[1:])):
            for k,sign in enumerate([-1,1]):
                r.append(dict(name=f'Roof bay {j+1} diagonal'+('.001' if k else ''),rear=False,a=[a,sign*Y,Z],b=[b,-sign*Y,Z],axis_y=[0,0,1],width=.045,depth=.045))
    return r

def shore_mass(family):
    # 70x70x3.175 mm tube plus displayed 20 mm thick top and bottom plates.
    vertical_depth={'flat':.06,'edge':.10,'grid4':.1016,'grid6':.1524,'grid4b8':.1016,'grid6b8':.1524}[family]
    length=Z-vertical_depth/2-.02-(2.787072+.02)
    volume=section(.07,.07,.93*.003175)[0]*length+(.18*.16+.60*.18)*.02
    return volume*RHO*GRAVITY/LBF

def mass(r,wall,pairs,family):
    # Idealization extends uprights and joist ends; solver dead load is authoritative.
    return sum(math.dist(m['a'],m['b'])*section(m['width'],m['depth'],m.get('wall',wall))[0]*RHO*GRAVITY/LBF for m in r)+2*pairs*shore_mass(family)
