# Accessible shared structure — iteration 05

Design comparison, not fabrication instructions or an occupied-deck rating.
Date: 2026-11-14 Pacific. See the published report for the full assumptions.

Run `python3 reproduce05.py` for the selected 250 lb equipment case and its
pinned-foot, 3x and refinement sensitivities. Run `python3 reproduce05.py --all`
to replay the complete saved exploration (Python 3 + NumPy required).
Force/moment equilibrium is asserted in each solve by `screen04.py`.

`study05.py` adds explicit side chords, webs and ties to iteration 04's geometry.
No skin stiffness or plywood diaphragm is credited. The exploration JSON files
contain solver inputs alongside their results. `equipment05.json` is the final
interactive basis: 8/12/20 people, 0/250/500/1000 lb service-storage allowance,
2,311.25 lb of skins/mounts, 2x live force, no body support. The default is 20
people and 250 lb of light controllers, cables and small totes, a placeholder.
The roof remains 38x8 ft at the original raised-deck datum.

The final `access='reinforced'`, depth 0.8 m model omits web 4 on both sides
permanently, increases jambs 4/5 to 4x2x1/8, and uses 6x2x3/16 lower chords.
Its cross-ties are raised to z=3.21 m to clear the reference bus roof. Nominal
openings are 50.5x25.5 inches. Preserve a 24-inch central service strip, reachable
trays and removable nonstructural skin panels. Actual trays, ventilation,
restraint, local loads, equipment inventory and loaded clearances are unverified.
Do not substitute the earlier 0.9 m trial's bottom-level ties: those collide
with the reference roof. The access=True unreinforced rows are rejected trials.

All stiffness uses ideal rigid joints. Both fixed-seat and pinned-seat results
retain translational restraint at the rail seats, whose true behavior is unknown.
Rear drop-frame transfer remains an owner-authorized assumption. The final
candidate's 3x rhythmic-force sensitivity exceeds the 207 MPa normal-stress
screen. Buckling, axial/bending interaction, shear/torsion, joints, concentrated
hangers, complete mass, wind, vehicle dynamics, fatigue and cabin protection
are not established. Square/metric reference properties are sharp-corner
approximations; catalog rectangular HSS values are from the included source.

Mass accounting includes explicit member/plywood gravity, full skins and the
selected storage allowance. It excludes as-yet-unweighed mounting reinforcement,
gussets, splices, guards, stairs, speakers and actual storage trays. Moving skin
load off the roof requires another vehicle load path; no total mass saving is
claimed. Bodies and chassis must be surveyed before choosing attachments.

`screen04.py`, `bearing04.py`, `design04.py`, `geometry-38.json`,
`hss-properties.json` and `build_shoring.py` are inherited from iteration 04.
Earlier report/solver archives remain published separately.
