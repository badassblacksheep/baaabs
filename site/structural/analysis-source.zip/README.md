# Earl roof-frame load explorer
Install Python 3 and NumPy. From the extracted directory run:

    OPENBLAS_NUM_THREADS=1 python3 build.py

This regenerates load-cases.json for every slider setting, plus three intermediate wall files. Use the geometry, assumptions, units, and limitations published with the report at https://baaabs.org/structural/. The pinned base GLB is at badassblacksheep/baaabs commit 031363d6a1605d149b914a9a5ba917eb15c3d367, site/assets/models/earl-roof-attachment-study.glb. The geometry.json table includes the site's generated mirrored rear members. Names marked rear are removed for the base model. Coordinates and section dimensions are metres. These are analytical centerline data, not shop drawings.

The results cover fixed rail seats, physically touching roof intersections and uniform assumed effective tube walls. The sampled-position maxima are independent for stress, drop, post force, and uplift. The solver checks gravity load and reaction equilibrium and closed-form element examples. No design or occupancy rating is issued.

screen.py and stability.py also support the archived 20-person reference runs; single.json is the earlier lower-deck single-post comparison. The two CSV diagnostic scripts can be run separately via python3 screen.py and python3 stability.py. Their named reference cases do not include all headcounts or the sweep. For a custom secondary condition, import analyze from screen and pass the desired geometry, wall, base, crossing condition, subdivision count, dancers and patches.
