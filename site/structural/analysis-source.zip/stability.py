"""First-order axial-force geometric-stiffness diagnostics on the reference models."""
import numpy as np
from screen import HERE, CASES, LBF, E, analyze, save, json


def geometric_stiffness(L, tension):
    block = np.array([[36,3*L,-36,3*L],[3*L,4*L**2,-3*L,-L**2],
                      [-36,-3*L,36,-3*L],[3*L,-L**2,-3*L,4*L**2]]) * tension/(30*L)
    kg = np.zeros((12,12))
    kg[np.ix_([1,5,7,11],[1,5,7,11])] = block
    signs=np.array([1,-1,1,-1])
    kg[np.ix_([2,4,8,10],[2,4,8,10])] = np.outer(signs,signs)*block
    return kg


def eigen_pair(k, g):
    # Cholesky congruence makes the buckling operator real symmetric.
    factor=np.linalg.cholesky(k)
    left=np.linalg.solve(factor,-g)
    h=np.linalg.solve(factor,left.T)
    ev,vec=np.linalg.eigh((h+h.T)*.5)
    assert ev[-1]>0
    lam=1/ev[-1]
    mode=np.linalg.solve(factor.T,vec[:,-1])
    err=np.linalg.norm(k@mode+lam*(g@mode))/np.linalg.norm(k@mode)
    assert err<2e-6
    return lam,err


def euler_test():
    from screen import beam,section
    n=10;length=3.;sec=section(.06,.06,.003175)
    K=np.zeros((6*(n+1),6*(n+1)));G=np.zeros_like(K)
    for i in range(n):
        L,_,_,el=beam(np.zeros(3),np.array([length/n,0,0]),np.array([0.,1,0]),sec)
        ids=np.arange(6*i,6*i+12);K[np.ix_(ids,ids)]+=el;G[np.ix_(ids,ids)]+=geometric_stiffness(L,-1.)
    get,_=eigen_pair(K[6:,6:],G[6:,6:])
    exact=np.pi**2*E*sec[1]/(2*length)**2
    assert abs(get/exact-1)<1e-4
    return get/exact


def check_frame_stability(K,free,elements,U,F,R,support,nodes,deck_ids,layout):
    rows=[]
    for c in [1,3,5]:
        G=np.zeros((len(U),len(U)))
        for ids,m,L,r,T,k,dens,equiv,sec,ni,nj in elements:
            end=k@(T@U[ids,c])-equiv[:,c]
            tension=(end[6]-end[0])/2
            G[np.ix_(ids,ids)]+=T.T@geometric_stiffness(L,tension)@T
        g=G[np.ix_(free,free)]
        factor,err=eigen_pair(K,g)
        disp=np.zeros(len(U));disp[free]=np.linalg.solve(K+g,F[free,c])
        rows.append(dict(layout=layout,case=CASES[c],ideal_elastic_buckling_multiplier=round(factor,4),
                         prestress_deck_drop_in=round(-disp[2::6][deck_ids].min()/.0254,5),
                         residual=round(err,9)))
    return rows


if __name__=='__main__':
    print('Cantilever numerical / Euler buckling load:',euler_test())
    rows=[];records=json.loads((HERE/'geometry.json').read_text())
    for layout in ['workshop_rear','base_glb']:
        rows+=analyze(records,layout,.003175,True,'touching',2,stability=True)
    save('stability.csv',rows)
    for row in rows:print(row)
