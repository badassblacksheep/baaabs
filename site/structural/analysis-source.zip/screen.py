"""Linear elastic frame screening. Run with Python 3 and NumPy in this directory."""
import csv
import json
import math
from pathlib import Path
import numpy as np

HERE = Path(__file__).resolve().parent
GRAVITY = 9.80665
LBF = 4.4482216152605
E = 200e9
G = E / (2 * (1 + 0.30))
RHO = 7850
PLY_PRESSURE = 0.01905 * 600 * GRAVITY
DECK_LENGTH = 10.9728
DECK_WIDTH = 2.4384
TEST_YIELD = 345e6
CASES = ('dead', 'uniform', 'party_half', 'party_midspan', 'passenger_half', 'party_rear')


def section(width, depth, wall):
    wi, di = width - 2*wall, depth - 2*wall
    area = width * depth - wi * di
    iy = (width * depth**3 - wi * di**3) / 12
    iz = (depth * width**3 - di * wi**3) / 12
    j = 2 * wall * ((width-wall)*(depth-wall))**2 / (width+depth-2*wall)
    return area, iy, iz, j


def beam(p, q, face_axis, sec):
    axis = (q-p) / np.linalg.norm(q-p)
    ey = face_axis - axis * (axis @ face_axis)
    ey /= np.linalg.norm(ey)
    r = np.array([axis, ey, np.cross(axis,ey)])
    trans = np.kron(np.eye(4),r)
    L = np.linalg.norm(q-p)
    area, iy, iz, j = sec
    k = np.zeros((12,12))
    def block(dofs, data):
        k[np.ix_(dofs,dofs)] += data
    pair=np.array([[1,-1],[-1,1]])
    block([0,6], E*area/L * pair)
    block([3,9], G*j/L * pair)
    bend = np.array([[12,6*L,-12,6*L],[6*L,4*L**2,-6*L,2*L**2],
                     [-12,-6*L,12,-6*L],[6*L,2*L**2,-6*L,4*L**2]])
    block([1,5,7,11], E*iz/L**3 * bend)
    flip=np.array([1,-1,1,-1])
    block([2,4,8,10], E*iy/L**3 * bend * np.outer(flip,flip))
    return L,r,trans,k


def distributed(q, L):
    """Consistent nodal load in beam coordinates for constant force per unit length."""
    f=np.zeros(12)
    f[:3]=f[6:9]=q*L/2
    f[4:6]=[-q[2]*L**2/12, q[1]*L**2/12]
    f[10:12]=-f[4:6]
    return f


def check_element():
    span, force, wall = 2.1, 1120., .003175
    sec=section(.06,.10,wall)
    L,r,T,k=beam(np.zeros(3),np.array([span,0.,0.]),np.array([0.,1,0]),sec)
    for axis,expected in [(0,force*L/(E*sec[0])), (1,force*L**3/(3*E*sec[2])),
                          (2,force*L**3/(3*E*sec[1]))]:
        f=np.zeros(6); f[axis]=force
        assert np.isclose(np.linalg.solve(k[6:,6:],f)[axis],expected,rtol=1e-10)
    f=distributed(np.array([0,0,-force]),L)
    tip=np.linalg.solve(k[6:,6:],f[6:])[2]
    assert np.isclose(tip,-force*L**4/(8*E*sec[1]),rtol=1e-10)
    reactions=k@np.r_[np.zeros(6),np.linalg.solve(k[6:,6:],f[6:])] - f
    assert np.isclose(abs(reactions[4]),force*L**2/2)


def idealize(records, rear, welded, refinement):
    members=[]
    joists=[m for m in records if m['name'].startswith('Floor joist')]
    girders=[m for m in records if m['name'].startswith('Deck edge')]
    y_edge=abs(girders[0]['a'][1]); top=girders[0]['a'][2]
    xfirst=joists[0]['a'][0]; has_return=any('Nose return' in m['name'] for m in records)
    bases=[]
    portal_xs=[m['a'][0] for m in records if m['name'].endswith('Front corner post') and (rear or not m['rear'])]
    sills={m['rear']:m['a'][2] for m in records if m['name'].endswith('Front transverse sill')}
    for src in records:
        if src['rear'] and not rear:continue
        m=dict(src)
        n=m['name'].split('mirror of ')[-1]
        a,b=np.array(m['a']),np.array(m['b'])
        if n.startswith('Floor joist'):a[1],b[1]=-y_edge,y_edge
        if n.startswith('Transverse deck bearer'): a[2]=b[2]=top
        if 'upright' in n:
            b[2]=top
            bases.append((a.copy(),n))
        if n.startswith('Front corner post'):a[2]=sills[m['rear']]
        if n.startswith('Front portal X'):a[0]=b[0]=min(portal_xs,key=lambda x:abs(x-a[0]))
        if has_return and n.startswith('Deck edge'):a[0]=xfirst
        if n.startswith('Nose return'):b[0]=xfirst
        if n=='Front transverse sill':
            for sign in [-1,1]:
                label=('Rear' if m['rear'] else 'Front')+(' driver sill seat' if sign<0 else ' passenger sill seat')
                bases.append((np.array([a[0],sign*.43,a[2]]),label))
        m.update(a=a,b=b,cuts=[0.,1.],short=n)
        members.append(m)
    def cut(m,t):
        if -1e-5<t<1+1e-5:m['cuts'].append(float(np.clip(t,0,1)))
    for i,m in enumerate(members):
        p=m['a']; d=m['b']-p
        if m['short'].startswith('Floor joist'):cut(m,.5)
        for base,_ in bases:
            t=(base-p)@d/(d@d)
            if np.linalg.norm(p+t*d-base)<1e-5:cut(m,t)
        for n in members[:i]:
            a=n['a']; v=n['b']-a
            mat=np.column_stack([d,-v])
            if np.linalg.matrix_rank(mat,tol=1e-7)<2:
                # Touching endpoints of adjacent collinear members already share a node.
                continue
            t,u=np.linalg.lstsq(mat,a-p,rcond=None)[0]
            if min(t,u)<-1e-5 or max(t,u)>1.00001 or np.linalg.norm(p+t*d-a-u*v)>1e-5:continue
            both_interior=min(t,1-t,u,1-u)>1e-5
            brace_to_bearer=(('Roof bay' in n['short'] and 'Transverse deck bearer' in m['short'])
                             or ('Roof bay' in m['short'] and 'Transverse deck bearer' in n['short']))
            if welded=='touching' and brace_to_bearer:continue
            if both_interior and (('portal X' in n['short'] and 'portal X' in m['short']) or
                    (welded=='ends_only' and ('Roof bay' in n['short'] or 'Roof bay' in m['short']))):continue
            cut(m,t);cut(n,u)
    nodes=[];els=[]; lookup={}
    def index(pt):
        key=tuple(pt)
        if key in lookup:return lookup[key]
        for coords, idx in lookup.items():
            if max(abs(v-u) for v,u in zip(coords,key)) < 4e-6:return idx
        lookup[key]=len(nodes);nodes.append(pt)
        return lookup[key]
    for m in members:
        cuts=sorted(set(round(t,7) for t in m['cuts']))
        intervals=[(i,j) for i,j in zip(cuts,cuts[1:]) if (j-i)*np.linalg.norm(m['b']-m['a'])>1e-5]
        for i,j in intervals:
            ts=np.linspace(i,j,refinement+1)
            for s,t in zip(ts,ts[1:]):
                p=m['a'] + s*(m['b']-m['a']);q=m['a'] + t*(m['b']-m['a'])
                # No connection at nonwelded crossings created accidentally by subdivisions.
                def endpoint(v,x):
                    if x not in (i,j) and ('Roof bay' in m['short'] or 'portal X' in m['short']):
                        nodes.append(v);return len(nodes)-1
                    return index(v)
                # Internal nodes of the same subdivision must share their DOFs.
                if s==i: prev=endpoint(p,s)
                nxt=endpoint(q,t);els.append((prev,nxt,m));prev=nxt
    support=[(index(p),n) for p,n in bases]
    return np.array(nodes),els,support,joists,girders


def analyze(records, layout, wall, fixed, welded, refinement, stability=False, dancers=20, patches=()):
    crowd_lbf = 225.0 * dancers
    cases = CASES + tuple(label for label, _, _ in patches)
    nodes,els,support,joists,girders=idealize(records,layout=='workshop_rear',welded,refinement)
    xmin,xmax=girders[0]['a'][0],girders[0]['b'][0]; yc=abs(girders[0]['a'][1])
    jx=np.array([j['a'][0] for j in joists]); bounds=np.r_[xmin,(jx[1:]+jx[:-1])/2,xmax]
    xmid=(xmin+xmax)/2; half_patch=1.8288
    n=len(nodes)*6; K=np.zeros((n,n)); F=np.zeros((n,len(cases))); elements=[]
    for ni,nj,m in els:
        p,q=nodes[ni],nodes[nj];w=m['width'];h=m['depth'];sec=section(w,h,wall)
        L,r,T,k=beam(p,q,np.array(m['axis_y']),sec)
        ids=np.r_[np.arange(ni*6,ni*6+6),np.arange(nj*6,nj*6+6)]
        K[np.ix_(ids,ids)]+=T.T@k@T
        # Positive weights downward. Distribute deck pressure to joists by tributary length.
        weight=np.full(len(cases),sec[0]*RHO*GRAVITY)
        if m['short'].startswith('Floor joist'):
            j=int(m['short'].split()[-1]);lo,hi=bounds[j:j+2];dx=hi-lo
            y=(p[1]+q[1])/2; live=crowd_lbf*LBF*dx/((xmax-xmin)*2*yc)
            weight+=PLY_PRESSURE*DECK_WIDTH*dx/(2*yc)
            weight[1]+=live
            weight[2]+=live*2 if y<0 else 0.
            overlap=max(0,min(hi,xmid+half_patch)-max(lo,xmid-half_patch))
            weight[3]+=crowd_lbf*LBF*overlap/(2*half_patch*yc) if y<0 else 0.
            weight[4]+=live*2 if y>0 else 0.
            rear_overlap=max(0,min(hi,xmax)-max(lo,xmax-2*half_patch))
            weight[5]+=crowd_lbf*LBF*rear_overlap/(2*half_patch*yc) if y<0 else 0.
            for i, (_, start_ft, length_ft) in enumerate(patches, start=len(CASES)):
                x0=xmin+start_ft*.3048; patch_length=length_ft*.3048
                loaded=max(0.,min(hi,x0+patch_length)-max(lo,x0))
                if y<0:weight[i]+=crowd_lbf*LBF*loaded/(patch_length*yc)
        local_dens=np.outer(r@np.array([0,0,-1.]),weight)
        equiv=np.stack([distributed(ld,L) for ld in local_dens.T],axis=1)
        F[ids]+=T.T@equiv
        elements.append((ids,m,L,r,T,k,local_dens,equiv,sec,ni,nj))
    constrained=np.array(sorted(ind for node,label in support for ind in range(node*6,node*6+(6 if fixed else 3))))
    free=np.setdiff1d(np.arange(n),constrained)
    U=np.zeros_like(F); Kfree=K[np.ix_(free,free)]
    # A Cholesky factorization independently checks for rigid-body mechanisms.
    np.linalg.cholesky(Kfree)
    U[free]=np.linalg.solve(Kfree,F[free])
    R=K@U-F
    assert np.max(abs(R[free])) < 1e-5*max(abs(F).max(),1.)
    RR=R.reshape(-1,6,len(cases)); FF=F.reshape(-1,6,len(cases))
    total=-FF[:,2,:].sum(0)/LBF
    assert np.allclose(total[1:]-total[0],crowd_lbf,atol=1e-3)
    forces=RR[:,:3]+FF[:,:3]
    moments=RR[:,3:]+FF[:,3:]+np.cross(nodes[:,:,None],forces,axisa=1,axisb=1,axisc=1)
    assert np.max(abs(forces.sum(0)))<.02 and np.max(abs(moments.sum(0)))<.03
    results=[];reactions=[]
    roofz=girders[0]['a'][2]
    for c,case in enumerate(cases):
        deck_ids=np.where((abs(nodes[:,2]-roofz)<1e-4) & (nodes[:,0]>=xmin-1e-5) & (nodes[:,0]<=xmax+1e-5))[0]
        uz=U[2::6,c]; worst=deck_ids[np.argmin(uz[deck_ids])]
        stress_record=(0.,'',0.)
        posts=[];post_s=0.; upright_max=(0.,''); axial_ratio=0.
        for ids,m,L,r,T,k,dens,equiv,sec,ni,nj in elements:
            f=k@(T@U[ids,c])-equiv[:,c]; load=dens[:,c]; area,iy,iz,j=sec
            # Left-end resultant plus distributed load gives internal forces at x (opposite face sign).
            # N signed positive tension. Bending sign convention irrelevant to corner envelope.
            for x in (0,L/2,L):
                axial=-(f[0]+load[0]*x)
                my=f[4]+f[2]*x+load[2]*x*x/2
                mz=f[5]-f[1]*x-load[1]*x*x/2
                s=abs(axial)/area + abs(my)*m['depth']/(2*iy)+abs(mz)*m['width']/(2*iz)
                xpos=nodes[ni,0]+(nodes[nj,0]-nodes[ni,0])*x/L
                if s>stress_record[0]:stress_record=(s,m['name'],xpos)
                if 'upright' in m['short'] or 'corner post' in m['short']:
                    compression=max(0,-axial)
                    posts.append((compression,m['name']))
                    post_s=max(post_s,s)
                    if 'upright' in m['short'] and compression>upright_max[0]:upright_max=(compression,m['name'])
                    pl=np.linalg.norm(m['b']-m['a'])
                    pe=np.pi**2*E*min(iy,iz)/pl**2
                    axial_ratio=max(axial_ratio,compression/pe)
                if x==L:
                    assert abs(my+f[10])<1e-4 and abs(mz+f[11])<1e-4
        peak,which=max(posts)
        name=lambda a: round(float(a),5)
        results.append(dict(layout=layout,wall_mm=wall*1000,base='fixed' if fixed else 'pinned',
                         roof_crossings=welded,case=case,
                         total_lbf=name(total[c]),deck_drop_in=name(-uz[worst]/.0254),
                         drop_x_m=name(nodes[worst,0]),drop_y_m=name(nodes[worst,1]),
                         peak_axial_post_lbf=name(peak/LBF),peak_axial_post=which,
                         max_upright_lbf=name(upright_max[0]/LBF),upright=upright_max[1],
                         max_post_normal_MPa=name(post_s/1e6),max_post_P_over_Euler_K1=name(axial_ratio),
                         max_normal_MPa=name(stress_record[0]/1e6),critical_member=stress_record[1],
                         critical_x_m=name(stress_record[2]),normal_over_assumed_Fy=name(stress_record[0]/TEST_YIELD)))
        for idx,label in support:
            fx,fy,fz,mx,my,mz=RR[idx,:,c]
            reactions.append(dict(layout=layout,wall_mm=wall*1000,base='fixed' if fixed else 'pinned',
                            roof_crossings=welded,case=case,support=label,
                            Fx_lbf=name(fx/LBF),Fy_lbf=name(fy/LBF),Fz_lbf=name(fz/LBF),
                            Mx_ftlb=name(mx/(LBF*.3048)),My_ftlb=name(my/(LBF*.3048)),Mz_ftlb=name(mz/(LBF*.3048))))
    if stability:
        from stability import check_frame_stability
        return check_frame_stability(Kfree, free, elements, U, F, R, support, nodes, deck_ids, layout)
    return results,reactions


def save(name,rows):
    with (HERE/name).open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)


if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser();ap.add_argument('--refinement',type=int,default=3)
    args=ap.parse_args();check_element()
    models=json.loads((HERE/'geometry.json').read_text())
    archived=json.loads((HERE/'single.json').read_text())
    results=[];reactions=[]
    for layout in ('base_glb','workshop_rear','archived_single'):
        for wall,fixed,welded in [(.003175,True,'touching'),(.0047625,True,'touching'),(.003175,False,'touching'),(.003175,True,'ends_only'),(.003175,True,'bridged_gap')]:
            if layout=='archived_single' and (not fixed or welded!='touching'):continue
            a,b=analyze(archived if layout=='archived_single' else models,layout,wall,fixed,welded,args.refinement)
            results.extend(a);reactions.extend(b)
    save('cases.csv',results);save('reactions.csv',reactions)
    print('Completed',len(results),'cases;',len(reactions),'support records.')
