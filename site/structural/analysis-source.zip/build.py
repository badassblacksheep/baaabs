"""Build the /structural display data using exact integer headcounts."""
import re
from screen import *
def footprint_sweep(length):
    last=36-length
    offsets=sorted({float(x) for x in range(int(last)+1)}|{last,last/2})
    return [(f'patch_{length:g}ft_at_{offset:g}ft',offset,length) for offset in offsets]



def summarize(rows, reactions):
    output={}
    for key, group in rows.items():
        stress=max(group,key=lambda r:r['max_normal_MPa'])
        drop=max(group,key=lambda r:r['deck_drop_in'])
        comp=max(group,key=lambda r:r['peak_axial_post_lbf'])
        rr=min((r for g in group for r in reactions[g['case']]),key=lambda r:r['Fz_lbf'])
        output[key]=dict(stress=round(stress['max_normal_MPa'],2),drop=round(drop['deck_drop_in'],3),
            post=round(comp['peak_axial_post_lbf']),uplift=max(0,round(-rr['Fz_lbf'])),support=rr['support'],
            member=stress['critical_member'],stressCase=stress['case'],dropCase=drop['case'],
            reactionCase=rr['case'],postCase=comp['case'])
    return output

def build_wall(wall):
    geom=json.loads((HERE/'geometry.json').read_text())
    results={}
    for layout in ('workshop_rear','base_glb'):
        dcounts=[]
        for n in range(21):
            patches=footprint_sweep(12.) if n else []
            if n and n!=20:patches+=footprint_sweep(.6*n)
            r,rx=analyze(geom,layout,wall,True,'touching',3,dancers=n,patches=patches)
            by_case={v['case']:v for v in r}
            reactions={k:[] for k in by_case}
            for v in rx:reactions[v['case']].append(v)
            swept=[v for v in r if v['case'].startswith('patch_')]
            groups={k:[by_case[k]] for k in ('uniform','party_half','party_midspan','party_rear')}
            groups['sweep']=swept or [by_case['dead']]
            dcounts.append(summarize(groups,reactions))
            if n==0:dead=by_case['dead']['total_lbf']
        results[layout]=dict(dead=round(dead,2),people=dcounts)
    (HERE/f'wall-{wall*1000:g}.json').write_text(json.dumps(results,separators=(',',':')))
if __name__=='__main__':
    check_element()
    thicknesses=(.003175,.0047625,.00635)
    for wall in thicknesses: build_wall(wall)
    walls=[json.loads((HERE/f'wall-{wall*1000:g}.json').read_text()) for wall in thicknesses]
    rows=json.loads((HERE/'geometry.json').read_text())
    girders=[r for r in rows if r['name'].startswith('Deck edge girder')]
    geom=dict(front=girders[0]['a'][0],lines=[],posts=[])
    for r in rows:
        name=r['name']
        if r['rear'] or not name.startswith(('Deck edge','Floor joist','Roof bay','Transverse deck bearer')): pass
        else:
            type_='girder' if name.startswith('Deck edge') else 'bearer' if name.startswith('Transverse') else 'joist' if name.startswith('Floor') else 'diagonal'
            geom['lines'].append([r['a'][:2],r['b'][:2],type_])
        if 'upright' in name or 'corner post' in name: geom['posts'].append([r['a'][:2],r['rear']])
    data=dict(yieldMPa=345,wallInches=[.125,.1875,.25],sourceRevision='031363d6a1605d149b914a9a5ba917eb15c3d367',geometry=geom,walls=walls)
    (HERE/'load-cases.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
