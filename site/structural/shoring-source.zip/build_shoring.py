"""Reproduce the 38 x 8 ft shoring study. Python 3 and NumPy."""
import sys
from screen import *

STIFFNESSES=[0,1000,5000,20000,'rigid']
def footprint_sweep(length):
    end=38-length
    offsets=sorted({float(x) for x in range(int(end)+1)}|{end,end/2})
    return [(f'patch_{length:g}ft_at_{offset:g}ft',offset,length) for offset in offsets]

def summarize(rows,reactions):
    reaction_sets={}
    for r in reactions:reaction_sets.setdefault(r['case'],[]).append(r)
    output={}
    groups={key:[r for r in rows if r['case']==key] for key in ('uniform','party_half','party_midspan','party_rear')}
    groups['sweep']=[r for r in rows if r['case'].startswith('patch_')] or [rows[0]]
    for label,group in groups.items():
        def peak(key):return max(group,key=lambda r:r[key])
        stress=peak('max_normal_MPa');drop=peak('deck_drop_in')
        reaction=min((rr for r in group for rr in reaction_sets[r['case']]),key=lambda r:r['Fz_lbf'])
        shore=peak('shore_peak_lbf')
        output[label]=dict(stress=round(stress['max_normal_MPa'],2),drop=round(drop['deck_drop_in'],3),
          post=round(peak('peak_axial_post_lbf')['peak_axial_post_lbf']),uplift=max(0,round(-reaction['Fz_lbf'])),
          shore=round(shore['shore_peak_lbf']),shoreCase=shore['case'],
          shoreCompression=round(peak('shore_compression_in')['shore_compression_in'],3),
          totalShore=round(peak('shore_total_lbf')['shore_total_lbf']),support=reaction['support'],
          member=stress['critical_member'],stressCase=stress['case'],dropCase=drop['case'],
          postCase=peak('peak_axial_post_lbf')['case'],reactionCase=reaction['case'])
    return output

def build(wall):
    records=json.loads((HERE/'geometry-38.json').read_text())
    design=json.loads((HERE/'design.json').read_text());results=[]
    for k in STIFFNESSES:
        people=[]
        for n in range(21):
            patches=footprint_sweep(12.) if n else []
            if n and n!=20:patches+=footprint_sweep(.6*n)
            rows,reactions=analyze(records,'workshop_rear',wall,True,'touching',3,dancers=n,
                patches=patches,shore_points=design['shore_positions_m'],shore_k=float('inf') if k=='rigid' else k)
            people.append(summarize(rows,reactions))
            if n==0:dead=rows[0]['total_lbf']
        results.append(dict(k=k,people=people))
        print(wall,k,'completed',flush=True)
    (HERE/f'shoring-{wall*1000:g}.json').write_text(json.dumps(dict(dead=round(dead,2),supports=results),separators=(',',':')))

if __name__=='__main__':
    from bearing import check_bearings
    check_element();check_bearings()
    build(float(sys.argv[1]))
