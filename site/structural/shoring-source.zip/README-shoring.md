# Earl structural iteration 02 — 38 × 8 ft, Thomas shoring

Dated 2026-11-14. Parametric static study; no operating occupancy or fabrication release established.

## Reproduce

Python 3 and NumPy are required. Extract this archive into a directory, then run:

```sh
python3 verify.py
python3 build_shoring.py 0.003175
python3 build_shoring.py 0.0047625
python3 build_shoring.py 0.00635
python3 assemble.py
```

`shoring-data.json` is the site's interactive dataset. The included per-wall outputs allow `assemble.py` to reproduce it without rerunning the solves. `verification.json` records completed checks. On the checked mesh cases, peak stress and shore forces were unchanged at reported precision; sampled deflection changed by at most 0.00145 in. A finer sampling of deflection can increase or decrease its reported maximum because the node positions change.

`geometry.json` and `reference_screen.py` preserve iteration 01. `geometry-38.json` is the new analytical member schedule. Coordinates are metres: X longitudinal (front negative), Y lateral (driver side negative), Z vertical. `design.json` documents dimensions, shore locations and assumptions. The source mesh was extracted at repository commit 031363d6a1605d149b914a9a5ba917eb15c3d367. That GLB contains the front portal; the workshop generates a mirrored rear portal. Both are included in these analytical schedules.

## Owner-approved geometry change

The floor extends two feet forward, keeping its aft edge, width and height. The 38 ft length places front post centerlines about 3.46 in inside the floor. This replaces the previous 36 × 8 ft invariant because those posts previously lay about 20.54 in ahead of the floor. The two girders, 13 joists and four X bays follow the new footprint. Their cross sections are unchanged; original posts and portal supports stay at their coordinates. The extended girders replace the two front return members. Rear mirror members remain unchanged.

## Support assumptions

Both rear corners transfer gravity through the rear drop-frame to the chassis rails using the same idealized portal/sill sections and fixed rail-seat restraints as the front corners. This is an assumption, with actual Earl dimensions, stiffness and strength unverified. The original rear-engaged cases also assumed that load path.

One added vertical compression-only shore under each edge girder is placed midway between the interior bearers. These locations are a trial choice and have not been matched to measured body members. Effective stiffness is 0, 1,000, 5,000, 20,000 lbf/in or a rigid limit, independently applied to each complete shore-to-chassis path. No capacity follows from the assigned stiffness. Zero initial gap is assumed. Bearings open on upward roof movement and supply no tension, moment or lateral restraint. Original chassis seats retain six restrained degrees of freedom and may take tension.

`bearing.py` solves the unilateral contact problem by enumerating active sets using the free frame flexibility. Every case checks force and moment equilibrium, applied live load and spring force compatibility. Element tests cover axial and cantilever response; bearing tests cover compression, separation and the rigid limit. `verify.py` replays the original algorithm and compares refinements 3 and 5 on five full crowd sweeps.

## Loads and results

0–20 people at 225 lb each. Each case includes frame selfweight and 19.05 mm plywood at 600 kg/m³. New shore, plate and reinforcement mass remains unassigned. Other omitted loads include rails, art, stairs, equipment and dynamic effects. Effective walls apply to all modeled hollow tube members: 1/8, 3/16 or 1/4 in. E=200 GPa, nu=0.30, steel density=7,850 kg/m³ and assumed yield=345 MPa. Sharp-corner ideal sections are used.

The sweep uses 12 × 4 ft and (0.6 ft × people) × 4 ft crowd patches on the driver half. Patch positions advance one foot plus exact centered and aftmost positions. At zero people, every placement becomes the dead-load case. Individual result fields are independent maxima across the sampled cases; each has a governing case identifier. No continuous-position maximum or dynamic crowd response is claimed.

At 20 people and 5,000 lbf/in per shore:

| Wall | Peak normal stress | Peak deck drop | Peak force into one shore |
|---|---:|---:|---:|
| 1/8 in | 232 MPa | 1.04 in | 2,674 lbf |
| 3/16 in | 172 MPa | 0.82 in | 2,643 lbf |
| 1/4 in | 143 MPa | 0.72 in | 2,627 lbf |

The 1/8 in, 38 ft case without new shores reaches 449 MPa and 6.04 in. Shoring reduces girder bending; the forward transverse bearer governs the trial shored peak stress. Actual body landings, chassis interfaces, local buckling, connections, floor vibration, dynamic dancing and vehicle stability require engineering evaluation. Values above assumed yield lie outside linear elastic validity.
