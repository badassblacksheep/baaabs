"""Numerical checks for iteration 02; executable with Python and NumPy."""
import json
from pathlib import Path
import numpy as np
import screen, reference_screen
from bearing import check_bearings
from build_shoring import footprint_sweep
p=Path(__file__).parent
screen.check_element();check_bearings()
base=json.loads((p/'geometry.json').read_text());new=json.loads((p/'geometry-38.json').read_text());d=json.loads((p/'design.json').read_text())
# No new supports: the extended solver must replay the archived algorithm.
a,_=screen.analyze(base,'workshop_rear',.003175,True,'touching',3)
b,_=reference_screen.analyze(base,'workshop_rear',.003175,True,'touching',3)
for aa,bb in zip(a,b):
 for key in ('max_normal_MPa','deck_drop_in','total_lbf','peak_axial_post_lbf'):
  assert abs(aa[key]-bb[key])<1e-5,(key,aa[key],bb[key])
print('Archived 36 ft solver replay: equal to 1e-5 output units.',flush=True)
checks=[]
for wall,n,k in [(.003175,20,5000),(.00635,20,5000),(.003175,12,5000),(.003175,20,0),(.003175,20,float('inf'))]:
 patches=footprint_sweep(12.) + (footprint_sweep(.6*n) if n!=20 else [])
 results=[]
 for refinement in (3,5):
  rows,_=screen.analyze(new,'workshop_rear',wall,True,'touching',refinement,dancers=n,patches=patches,shore_k=k,shore_points=d['shore_positions_m'])
  sweep=[r for r in rows if r['case'].startswith('patch_')]
  results.append({key:max(r[key] for r in sweep)for key in ('max_normal_MPa','deck_drop_in','shore_peak_lbf')})
 differences={key:abs(results[1][key]-results[0][key])/max(abs(results[1][key]),1)*100 for key in results[0]}
 assert max(differences.values())<1.0,differences
 row=dict(wall_mm=wall*1000,people=n,k='rigid' if np.isinf(k)else k,refinement3=results[0],refinement5=results[1],difference_percent=differences);checks.append(row)
 print(json.dumps(row),flush=True)
(p/'verification.json').write_text(json.dumps(dict(element_checks='passed',compression_bearings='passed including opening and rigid limit',baseline_replay='equal to 1e-5 output units',mesh_checks=checks),indent=2)+'\n')
