"""Zero-gap compression bearings solved by enumerating the active set."""
import itertools
import numpy as np

def compression_bearings(stiffness, loads, dofs, spring_k):
    unit=np.eye(len(stiffness))[:,dofs]
    solutions=np.linalg.solve(stiffness,np.column_stack((loads,unit)))
    u0=solutions[:,:loads.shape[1]]
    influence=solutions[:,loads.shape[1]:]
    flexibility=influence[dofs]
    output=np.full_like(u0,np.nan)
    assigned=np.zeros(loads.shape[1],dtype=bool)
    for active in itertools.product((False,True),repeat=len(dofs)):
        a=np.flatnonzero(active)
        trial=u0.copy()
        forces=np.zeros((len(dofs),loads.shape[1]))
        if len(a):
            inverse_k=0. if np.isinf(spring_k) else 1./spring_k
            # Upward bearing forces balance the compressive downward displacement.
            forces[a]=np.linalg.solve(flexibility[np.ix_(a,a)]+np.eye(len(a))*inverse_k,-u0[dofs[a]])
            trial+=influence[:,a]@forces[a]
        valid=np.all(forces>=-1e-6,axis=0)
        inactive=np.flatnonzero(~np.array(active))
        if len(inactive):valid&=np.all(trial[dofs[inactive]]>=-1e-10,axis=0)
        valid&=~assigned
        output[:,valid]=trial[:,valid];assigned|=valid
    assert assigned.all(),'bearing complementarity failed'
    return output

def check_bearings():
    # One ground spring (10 N/m), one additional bearing (30 N/m).
    K=np.array([[10.]])
    f=np.array([[-40.,40.,0.]])
    u=compression_bearings(K,f,np.array([0]),30.)
    assert np.allclose(u,[[-1.,4.,0.]])
    u=compression_bearings(K,f,np.array([0]),float('inf'))
    assert np.allclose(u,[[0.,4.,0.]])
    K=np.array([[10.,-2.],[-2.,10.]])
    u=compression_bearings(K,np.array([[-10.,10.],[10.,-10.]]),np.array([0,1]),20)
    R=K@u-np.array([[-10.,10.],[10.,-10.]])
    assert np.allclose(R,np.maximum(0,-u)*20)
