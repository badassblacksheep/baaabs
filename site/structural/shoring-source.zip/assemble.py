"""Combine computed wall sweeps into the website data file."""
import json
from pathlib import Path
p=Path(__file__).parent
walls=[json.loads((p/f'shoring-{t}.json').read_text())for t in ('3.175','4.7625','6.35')]
design=json.loads((p/'design.json').read_text());records=json.loads((p/'geometry-38.json').read_text())
geometry=dict(front=design['deck_front_x_m'],lines=[],posts=[])
for m in records:
 n=m['name']
 if not m['rear'] and n.startswith(('Deck edge','Floor joist','Roof bay','Transverse deck bearer')):
  kind='girder' if n.startswith('Deck edge') else 'bearer' if n.startswith('Transverse') else 'joist' if n.startswith('Floor') else 'diagonal'
  geometry['lines'].append([m['a'][:2],m['b'][:2],kind])
 if 'upright' in n or 'corner post' in n:geometry['posts'].append([m['a'][:2],m['rear']])
data=dict(revision='02-thomas-shoring',yieldMPa=345,wallInches=[.125,.1875,.25],design=design,geometry=geometry,walls=walls)
(p/'shoring-data.json').write_text(json.dumps(data,separators=(',',':'))+'\n')
