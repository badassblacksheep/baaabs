"""Iteration 06: full-depth triangulation, six lower-node compression bearings.

The 115-inch pitch is an inferred four-module layout, NOT a measured bow map.
The springs represent shore + saddle + body + chassis compliance together.
No capacity, lateral restraint or uplift resistance is assigned to the body.
"""
import json, math
from pathlib import Path
import numpy as np
from study05 import geometry as geometry05
from design04 import positions, Y, Z
from screen04 import analyze, section, RHO, GRAVITY, LBF, check_element
from bearing04 import check_bearings
from build_shoring import footprint_sweep

HERE=Path(__file__).parent
PORTALS=(-6.27,4.81355)
CENTER=sum(PORTALS)/2
PITCH=115*.0254
DEPTH=.8
LANDING=2.787072
SHORE_WIDTH=.0762
SHORE_WALL=.003175
PAD=.01905
TOP_PLATE=(.18,.16)
BOTTOM_PLATE=(.60,.18)

def stations(shift=0.,pitch=PITCH):
    return [CENTER+shift+j*pitch for j in (-1,0,1)]

def shores(shift=0.,pitch=PITCH):
    return [[x,y,Z-DEPTH] for x in stations(shift,pitch) for y in (-Y,Y)]

def shore_mass():
    # Nominal sharp-corner mass is conservative; tube stiffness is subsumed in k.
    length=Z-DEPTH-.1524/2-LANDING-2*PAD
    volume=section(SHORE_WIDTH,SHORE_WIDTH,SHORE_WALL)[0]*length
    volume+=PAD*(math.prod(TOP_PLATE)+math.prod(BOTTOM_PLATE))
    return volume*RHO*GRAVITY/LBF

def geometry(shift=0.,pitch=PITCH):
    r=geometry05(.8,3,'grid6','larger','robust',False)
    old=[PORTALS[0],*positions(3,'portal'),PORTALS[1]]
    new=[PORTALS[0],*stations(shift,pitch),PORTALS[1]]
    for m in r:
        # Remesh joists, plan bracing and side-truss panels with the shores.
        if m['name'].startswith(('Floor joist','Roof bay','Truss ','Lower transverse tie')):
            for pt in (m['a'],m['b']):
                if PORTALS[0] <= pt[0] <= PORTALS[1]:pt[0]=float(np.interp(pt[0],old,new))
        if m['name'].startswith('Truss lower'):m['wall']=.93*.0047625
        if m['name'].startswith('Truss web'):
            # Diagonals converge at each shore's lower-chord node.
            m['a'][2],m['b'][2]=m['b'][2],m['a'][2]
        if m['name'].startswith('Lower transverse tie'):
            m['a'][2]=m['b'][2]=3.21  # Preserve clearance above modeled roof crown.
        m.setdefault('wall',.93*.003175)
    return r

def solve(people=20,extra_lbf=250.,k=5000.,alpha=2.,disabled=(),fixed=True,
          refinement=3,shift=0.,pitch=PITCH,label=''):
    patches=footprint_sweep(12.) if people else []
    if people and people!=20:patches+=footprint_sweep(min(38.,.6*people))
    rows,reactions=analyze(geometry(shift,pitch),'workshop_rear',.93*.003175,fixed,'touching',refinement,
        dancers=people,patches=patches,shore_points=shores(shift,pitch),shore_k=k,
        live_multiplier=alpha,shore_dead_lbf=shore_mass(),panel_lbf=2311.25+extra_lbf,
        nominal_mass=True,disabled_shores=disabled)
    s=max(rows,key=lambda r:r['max_normal_MPa'])
    d=max(rows,key=lambda r:r['deck_drop_in'])
    v=max(rows,key=lambda r:r['shore_peak_lbf'])
    result=dict(label=label,people=people,extraLbf=extra_lbf,k=k,alpha=alpha,fixed=fixed,
        disabled=list(disabled),refinement=refinement,shift=shift,pitch=pitch,
        stress=s['max_normal_MPa'],stressCase=s['case'],member=s['critical_member'],
        drop=d['deck_drop_in'],dropCase=d['case'],shore=v['shore_peak_lbf'],shoreCase=v['case'],
        shoreReactions=v['shore_reactions_lbf'],shoreMaxima=[max(x['shore_reactions_lbf'][j] for x in rows) for j in range(6)],
        frameWeight=rows[0]['total_lbf']-2311.25-extra_lbf,dead=rows[0]['total_lbf'],total=rows[-1]['total_lbf'],
        uplift=max(0,-min(x['Fz_lbf'] for x in reactions)),portalReaction=max(abs(x['Fz_lbf']) for x in reactions),
        maxPortalMoment=max(abs(x[a]) for x in reactions for a in ['Mx_ftlb','My_ftlb','Mz_ftlb']),
        belowCeiling=s['max_normal_MPa']<=207.,caseCount=len(rows))
    if label=='default':
        (HERE/'rows06.json').write_text(json.dumps(dict(cases=rows,reactions=reactions),indent=2)+'\n')
    return result

if __name__=='__main__':
    import argparse,time
    ap=argparse.ArgumentParser();ap.add_argument('--all',action='store_true');args=ap.parse_args()
    check_element();check_bearings()
    jobs=[dict(label='default')]
    if args.all:
        jobs += [dict(people=n,extra_lbf=e,label=f'crowd-{n}-gear-{e}') for n in (8,12,20) for e in (0,250,500,1000) if (n,e)!=(20,250)]
        jobs += [dict(k=k,label=f'k-{k}') for k in (0,1000,20000)]
        jobs += [dict(alpha=3,label='3x'),dict(fixed=False,label='pinned'),dict(refinement=5,label='fine')]
        jobs += [dict(disabled=[j],label=f'lost-{j}') for j in range(6)]
        jobs += [dict(disabled=[2*j,2*j+1],label=f'lost-pair-{j+1}') for j in range(3)]
        jobs += [dict(shift=s,label=f'phase-{s:+.5f}') for s in (-.365125,.365125)]
    out=[]
    for kw in jobs:
        start=time.time();r=solve(**kw);out.append(r)
        print(r['label'],r['stress'],r['drop'],r['shore'],r['member'],round(time.time()-start,2),flush=True)
        (HERE/'results06.json').write_text(json.dumps(out,indent=2)+'\n')
