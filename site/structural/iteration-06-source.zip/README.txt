Iteration 06 conceptual structural screen. Python 3 + NumPy.
Run: OPENBLAS_NUM_THREADS=1 python3 study06.py --all
Every solve checks force/moment equilibrium and exact applied crowd load.
Results include 12 crowd/gear cases and 17 support/force/refinement/phase sensitivities.
Compression springs connect at lower truss nodes. All members and gravity are explicit; the body stiffness/capacity remains unverified.
The 115-inch pair pitch and centered phase are layout assumptions, not fabrication locations.
